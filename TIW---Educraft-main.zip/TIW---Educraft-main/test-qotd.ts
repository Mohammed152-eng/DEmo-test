import { QuestionOfTheWeek } from "./src/mongo/index.ts";
console.log(typeof QuestionOfTheWeek.countDocuments);
