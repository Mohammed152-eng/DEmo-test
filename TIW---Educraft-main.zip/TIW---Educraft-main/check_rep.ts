import { connect } from "mongoose";
import { GuildPreferences } from "./src/mongo/schemas/GuildPreferences";
import { config } from "dotenv";
config();

async function check() {
  await connect(process.env.MONGO_URL as string);
  const prefs = await GuildPreferences.findOne({ guildId: process.env.MAIN_GUILD_ID });
  console.log("Prefs:", prefs);
  process.exit(0);
}
check();