import { exec } from 'child_process';
const child = exec('NODE_ENV=production npx tsx src/index.ts');
child.stdout.on('data', console.log);
child.stderr.on('data', console.error);
setTimeout(() => {
  fetch('http://localhost:3000/').then(r => r.text()).then(console.log).catch(console.error);
  setTimeout(() => process.exit(0), 2000);
}, 5000);
