import { config } from "dotenv";
config();
import mongoose from "mongoose";

async function run() {
	await mongoose.connect(process.env.MONGO_URL as string);
	const adminDb = mongoose.connection.db?.admin();
	const dbs = await adminDb?.listDatabases();
	
	for (const dbInfo of dbs?.databases || []) {
		const db = mongoose.connection.useDb(dbInfo.name);
		const collections = await db.db?.listCollections().toArray();
		console.log(`DB: ${dbInfo.name}`);
		
		if (collections?.some(c => c.name.toLowerCase().includes('question'))) {
			for (const c of collections.filter(c => c.name.toLowerCase().includes('question'))) {
				const count = await db.collection(c.name).countDocuments();
				console.log(`  -> ${c.name} count: ${count}`);
			}
		}
	}
	
	await mongoose.disconnect();
}

run().catch(console.error);
