const regex = /(.*_confession)_(accept|reject|ban|edit)/gi;
console.log(regex.exec('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed_confession_accept'));
