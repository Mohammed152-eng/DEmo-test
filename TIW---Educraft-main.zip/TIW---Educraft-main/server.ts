import "dotenv/config";
import express from "express";
import path from "node:path";
import fs from "node:fs";
import { registerCommands, registerEvents, syncCommands } from "./src/registry";
import { Logger } from "@discordforge/logger";
import { GatewayIntentBits, Partials } from "discord.js";
import mongo from "mongoose";
import { redis, initRedis } from "./src/redis";
import { DiscordClient } from "./src/registry/DiscordClient";

const HEX_REGEX = /^#?([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;

export const client = new DiscordClient({
	intents: [
		GatewayIntentBits.AutoModerationConfiguration,
		GatewayIntentBits.AutoModerationExecution,
		GatewayIntentBits.DirectMessageReactions,
		GatewayIntentBits.DirectMessageTyping,
		GatewayIntentBits.DirectMessages,
		GatewayIntentBits.GuildEmojisAndStickers,
		GatewayIntentBits.GuildIntegrations,
		GatewayIntentBits.GuildInvites,
		GatewayIntentBits.GuildMembers,
		GatewayIntentBits.GuildMessageReactions,
		GatewayIntentBits.GuildMessageReactions,
		GatewayIntentBits.GuildMessageTyping,
		GatewayIntentBits.GuildMessages,
		GatewayIntentBits.GuildModeration,
		GatewayIntentBits.GuildScheduledEvents,
		GatewayIntentBits.GuildVoiceStates,
		GatewayIntentBits.GuildWebhooks,
		GatewayIntentBits.Guilds,
		GatewayIntentBits.MessageContent,
	],
	partials: [Partials.Message, Partials.Channel, Partials.Reaction],
	allowedMentions: {
		parse: ["users", "roles"],
		repliedUser: true,
	},
});

interface MessageLog {
	id: string;
	guildId: string;
	channelId: string;
	channelName: string;
	userId: string;
	username: string;
	action: 'CREATE' | 'UPDATE' | 'DELETE' | 'WARN';
	content: string;
	timestamp: number;
}

const messageLogs: MessageLog[] = [];

function addLog(log: MessageLog) {
	messageLogs.unshift(log);
	if (messageLogs.length > 1000) messageLogs.pop();
}

client.on('messageCreate', message => {
	if (!message.guild || message.author.bot) return;
	addLog({
		id: message.id,
		guildId: message.guild.id,
		channelId: message.channel.id,
		channelName: ('name' in message.channel ? message.channel.name : 'unknown') as string,
		userId: message.author.id,
		username: message.author.username,
		action: 'CREATE',
		content: message.content,
		timestamp: Date.now()
	});
});

client.on('messageUpdate', (oldMessage, newMessage) => {
	if (!newMessage.guild || newMessage.author?.bot) return;
	addLog({
		id: newMessage.id,
		guildId: newMessage.guild.id,
		channelId: newMessage.channel.id,
		channelName: ('name' in newMessage.channel ? newMessage.channel.name : 'unknown') as string,
		userId: newMessage.author?.id || 'unknown',
		username: newMessage.author?.username || 'unknown',
		action: 'UPDATE',
		content: `Old: ${oldMessage.content}\nNew: ${newMessage.content}`,
		timestamp: Date.now()
	});
});

client.on('messageDelete', message => {
	if (!message.guild || message.author?.bot) return;
	addLog({
		id: message.id,
		guildId: message.guild.id,
		channelId: message.channel.id,
		channelName: ('name' in message.channel ? message.channel.name : 'unknown') as string,
		userId: message.author?.id || 'unknown',
		username: message.author?.username || 'unknown',
		action: 'DELETE',
		content: message.content || 'Unknown content',
		timestamp: Date.now()
	});
});

async function startServer() {
	const app = express();
	const PORT = 3000;

	app.use(express.json());

	// API routes go here
	app.get("/api/health", (req, res) => {
		res.json({ status: "ok" });
	});

	app.get("/api/status", (req, res) => {
		res.json({
			status: client.isReady() ? "Online" : "Offline",
			ping: client.ws.ping,
			uptime: client.uptime
		});
	});

	app.get("/api/servers", async (req, res) => {
		try {
			Logger.info(`Client ready: ${client.isReady()}, Client guilds cache size: ${client.guilds.cache.size}`);
			
			if (!client.isReady()) {
				return res.json({
					servers: [],
					debug: {
						isReady: false,
						cacheSize: 0,
						fetchedSize: 0,
						token: process.env.BOT_TOKEN ? "Present" : "Missing"
					}
				});
			}

			const oauthGuilds = await client.guilds.fetch();
			const servers = oauthGuilds.map(guild => ({
				id: guild.id,
				name: guild.name,
				memberCount: client.guilds.cache.get(guild.id)?.memberCount || 0,
			}));
			
			res.json({
				servers,
				debug: {
					isReady: client.isReady(),
					cacheSize: client.guilds.cache.size,
					fetchedSize: oauthGuilds.size,
					token: process.env.BOT_TOKEN ? "Present" : "Missing"
				}
			});
		} catch (error) {
			Logger.error(`Failed to fetch servers: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch servers" });
		}
	});

	app.get("/api/servers/:guildId/users", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const query = req.query.q as string;
			let members: import("discord.js").Collection<string, import("discord.js").GuildMember>;
			if (query) {
				members = await guild.members.fetch({ query, limit: 50 });
			} else {
				members = await guild.members.fetch({ limit: 100 });
			}
			res.json(members.map(m => ({ 
				id: m.id, 
				username: m.user.username, 
				avatar: m.user.displayAvatarURL(),
				color: m.displayHexColor === '#000000' ? '#ffffff' : m.displayHexColor 
			})));
		} catch (error) {
			Logger.error(`Failed to fetch users: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch users" });
		}
	});

	app.get("/api/servers/:guildId/channels", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const channels = await guild.channels.fetch();
			const textChannels = channels.filter(c => c?.isTextBased()).map(c => ({
				id: c?.id || '',
				name: c?.name || ''
			}));
			res.json(textChannels);
		} catch (error) {
			Logger.error(`Failed to fetch channels: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch channels" });
		}
	});

	app.get("/api/servers/:guildId/roles", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const roles = await guild.roles.fetch();
			res.json(roles.map(r => ({ id: r.id, name: r.name, color: r.hexColor })));
		} catch (error) {
			Logger.error(`Failed to fetch roles: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch roles" });
		}
	});

	app.post("/api/servers/:guildId/members/:memberId/roles", async (req, res) => {
		const { roleId, action } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const member = await guild.members.fetch(req.params.memberId);
			if (action === 'add') {
				await member.roles.add(roleId);
			} else if (action === 'remove') {
				await member.roles.remove(roleId);
			}
			res.json({ status: "success" });
		} catch (error) {
			Logger.error(`Failed to modify role: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to modify role" });
		}
	});

	app.delete("/api/servers/:guildId/members/:memberId/color", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const member = await guild.members.fetch(req.params.memberId);
			
			const { CustomColorRole } = await import("./src/mongo");
			const existingColorRole = await CustomColorRole.findOne({ guildId: guild.id, userId: member.id });
			
			let role = existingColorRole ? guild.roles.cache.get(existingColorRole.roleId) : null;
			if (!role) {
				role = guild.roles.cache.find((r) => r.name === `Color-${member.id}`);
			}
			
			if (role) {
				await role.delete("Custom color removed via dashboard").catch((e) => Logger.error(`Failed to delete custom color role: ${e}`));
			}

			await CustomColorRole.deleteOne({ guildId: guild.id, userId: member.id });

			res.json({ status: "success" });
		} catch (error: unknown) {
			Logger.error(`Failed to remove color: ${error}`);
			res.status(500).json({ status: "error", message: error instanceof Error ? error.message : "Failed to remove color" });
		}
	});

	app.post("/api/servers/:guildId/members/:memberId/color", async (req, res) => {
		const { hexColor, name } = req.body;
		try {
			if (!HEX_REGEX.test(hexColor)) {
				return res.status(400).json({ status: "error", message: "Invalid hex color code" });
			}

			const guild = await client.guilds.fetch(req.params.guildId);
			const member = await guild.members.fetch(req.params.memberId);
			
			const roleName = name || `Color-${member.id}`;
			
			const { CustomColorRole } = await import("./src/mongo");
			const existingColorRole = await CustomColorRole.findOne({ guildId: guild.id, userId: member.id });
			
			// Find existing custom color role for this user safely
			let role = existingColorRole ? guild.roles.cache.get(existingColorRole.roleId) : null;
			if (!role) {
				role = guild.roles.cache.find(r => r.name === `Color-${member.id}`);
			}
			
			let formattedHex = (hexColor.startsWith("#") ? hexColor : `#${hexColor}`).toUpperCase() as `#${string}`;
			if (formattedHex === "#000000") {
				formattedHex = "#000001";
			}

			const botHighestRole = guild.members.me?.roles.highest;
			
			const userColoredRoles = member.roles.cache.filter(r => r.color !== 0 && (!role || r.id !== role.id));
			const highestUserColorRole = userColoredRoles.sort((a, b) => b.position - a.position).first();
			
			if (highestUserColorRole && botHighestRole && highestUserColorRole.position >= botHighestRole.position) {
				return res.status(400).json({ 
					status: "error", 
					message: `Cannot apply color because the user has a colored role (${highestUserColorRole.name}) that is higher than the bot's highest role. Please move the bot's role higher in the server settings.` 
				});
			}

			// Always try to put custom colors as high as possible so they override milestone roles
			const targetPosition = botHighestRole ? Math.max(1, botHighestRole.position - 1) : 1;

			if (targetPosition <= 1) {
				Logger.warn(`Bot's highest role is too low to effectively manage custom colors. Please move the bot's role higher in the server settings.`);
			}

			if (role) {
				try {
					await role.edit({
						name: roleName,
						color: formattedHex,
					});
					const currentBotRole = guild.members.me?.roles.highest;
					const editTargetPosition = currentBotRole ? Math.max(1, currentBotRole.position - 1) : 1;
					await role.setPosition(editTargetPosition);
				} catch (e: unknown) {
					throw new Error(`Failed to edit existing role: ${e instanceof Error ? e.message : String(e)}`);
				}
			} else {
				try {
					role = await guild.roles.create({
						name: roleName,
						color: formattedHex,
						reason: "Custom color role set via dashboard",
					});
					// Recalculate target position because creating a role shifts all higher roles up by 1
					const currentBotRole = guild.members.me?.roles.highest;
					const createTargetPosition = currentBotRole ? Math.max(1, currentBotRole.position - 1) : 1;
					await role.setPosition(createTargetPosition);
				} catch (e: unknown) {
					throw new Error(`Failed to create role: ${e instanceof Error ? e.message : String(e)}`);
				}
			}

			// Remove other color roles from the member
			const { ColorRole } = await import("./src/mongo");
			const guildColorRoles = await ColorRole.find({ guildId: guild.id });
			const guildColorRoleIds = guildColorRoles.map(r => r.roleId);
			
			const colorRolesToRemove = member.roles.cache.filter(r => 
				(r.name.startsWith("Color-") && r.id !== role?.id) || 
				guildColorRoleIds.includes(r.id)
			);
			if (colorRolesToRemove.size > 0) {
				await member.roles.remove(colorRolesToRemove).catch((e) => Logger.error(`Error removing old color roles: ${e}`));
			}

			if (!member.roles.cache.has(role.id)) {
				await member.roles.add(role).catch((e: Error) => {
					Logger.error(`Failed to add role to member: ${e}`);
					throw new Error(`Failed to add role to user: ${e.message}`);
				});
			}

			// Save to DB
			await CustomColorRole.updateOne(
				{ guildId: guild.id, userId: member.id },
				{ $set: { roleId: role.id } },
				{ upsert: true }
			);

			res.json({ status: "success" });
		} catch (error: unknown) {
			Logger.error(`Failed to set color: ${error}`);
			res.status(500).json({ status: "error", message: error instanceof Error ? error.message : "Failed to set color" });
		}
	});

	app.get("/api/servers/:guildId/members/:memberId/rep", async (req, res) => {
		try {
			const { Reputation } = await import("./src/mongo");
			const repDoc = await Reputation.findOne({
				guildId: req.params.guildId,
				userId: req.params.memberId,
			});
			res.json({ rep: repDoc?.rep || 0 });
		} catch (error) {
			Logger.error(`Failed to fetch rep: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch rep" });
		}
	});

	app.post("/api/servers/:guildId/members/:memberId/rep", async (req, res) => {
		const { rep } = req.body;
		try {
			const { Reputation } = await import("./src/mongo");
			await Reputation.findOneAndUpdate(
				{ guildId: req.params.guildId, userId: req.params.memberId },
				{ $set: { rep: Number(rep) } },
				{ upsert: true }
			);
			res.json({ status: "success" });
		} catch (error) {
			Logger.error(`Failed to set rep: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to set rep" });
		}
	});

	app.get("/api/servers/:guildId/roles", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const roles = guild.roles.cache.map(role => ({
				id: role.id,
				name: role.name,
				color: role.hexColor,
				position: role.position,
				members: role.members.size,
				managed: role.managed
			})).sort((a, b) => b.position - a.position);
			res.json(roles);
		} catch (error) {
			Logger.error(`Failed to fetch roles: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch roles" });
		}
	});

	app.delete("/api/servers/:guildId/roles/:roleId", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const role = await guild.roles.fetch(req.params.roleId);
			
			if (!role) {
				return res.status(404).json({ status: "error", message: "Role not found" });
			}

			const botHighestRole = guild.members.me?.roles.highest;
			if (!botHighestRole || role.position >= botHighestRole.position) {
				return res.status(403).json({ status: "error", message: "Cannot delete a role higher than or equal to the bot's highest role" });
			}

			await role.delete("Deleted via dashboard");
			res.json({ status: "success" });
		} catch (error) {
			Logger.error(`Failed to delete role: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to delete role" });
		}
	});

	app.post("/api/servers/:guildId/roles", async (req, res) => {
		const { name, color } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			
			if (!name) {
				return res.status(400).json({ status: "error", message: "Role name is required" });
			}

			const formattedHex = color ? (color.startsWith("#") ? color : `#${color}`).toUpperCase() as `#${string}` : undefined;

			const role = await guild.roles.create({
				name,
				color: formattedHex,
				reason: "Role created via dashboard",
			});

			res.json({ status: "success", role: { id: role.id, name: role.name, color: role.hexColor } });
		} catch (error: unknown) {
			Logger.error(`Failed to create role: ${error}`);
			res.status(500).json({ status: "error", message: error instanceof Error ? error.message : "Failed to create role" });
		}
	});

	app.patch("/api/servers/:guildId/roles/:roleId", async (req, res) => {
		const { name, color } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const role = await guild.roles.fetch(req.params.roleId);
			
			if (!role) {
				return res.status(404).json({ status: "error", message: "Role not found" });
			}

			const botHighestRole = guild.members.me?.roles.highest;
			if (!botHighestRole || role.position >= botHighestRole.position) {
				return res.status(403).json({ status: "error", message: "Cannot edit a role higher than or equal to the bot's highest role" });
			}

			const updates: import("discord.js").RoleEditOptions = {};
			if (name) updates.name = name;
			if (color && HEX_REGEX.test(color)) {
				updates.color = (color.startsWith("#") ? color : `#${color}`).toUpperCase() as `#${string}`;
			}

			if (Object.keys(updates).length > 0) {
				updates.reason = "Edited via dashboard";
				await role.edit(updates);
			}

			res.json({ status: "success" });
		} catch (error) {
			Logger.error(`Failed to edit role: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to edit role" });
		}
	});

	app.get("/api/servers/:guildId/logs", (req, res) => {
		const guildLogs = messageLogs.filter(log => log.guildId === req.params.guildId);
		res.json(guildLogs.slice(0, 100)); // Return last 100 logs
	});

	app.post("/api/servers/:guildId/channels/:channelId/slowmode", async (req, res) => {
		const { rateLimitPerUser } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const channel = await guild.channels.fetch(req.params.channelId);
			if (channel?.isTextBased() && 'setRateLimitPerUser' in channel) {
				await (channel as import('discord.js').TextChannel).setRateLimitPerUser(rateLimitPerUser);
				res.json({ status: "success" });
			} else {
				res.status(400).json({ status: "error", message: "Invalid channel" });
			}
		} catch (error) {
			Logger.error(`Failed to set slowmode: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to set slowmode" });
		}
	});

	app.post("/api/servers/:guildId/channels/:channelId/clear", async (req, res) => {
		const { amount } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const channel = await guild.channels.fetch(req.params.channelId);
			if (channel?.isTextBased() && 'bulkDelete' in channel) {
				await (channel as import('discord.js').TextChannel).bulkDelete(amount, true);
				res.json({ status: "success" });
			} else {
				res.status(400).json({ status: "error", message: "Invalid channel" });
			}
		} catch (error) {
			Logger.error(`Failed to clear messages: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to clear messages" });
		}
	});

	app.get("/api/servers/:guildId/modmail", async (req, res) => {
		try {
			const { PrivateDmThread } = await import("./src/mongo/schemas/PrivateDmThread.js");
			const threads = await PrivateDmThread.find({ guildId: req.params.guildId });
			const result = [];
			for (const t of threads) {
				try {
					const user = await client.users.fetch(t.userId);
					result.push({
						id: t.threadId,
						userId: t.userId,
						username: user.username,
						avatar: user.displayAvatarURL()
					});
				} catch (e) {
					result.push({
						id: t.threadId,
						userId: t.userId,
						username: "Unknown User",
						avatar: ""
					});
				}
			}
			res.json(result);
		} catch (error) {
			Logger.error(`Failed to fetch modmail threads: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch modmail threads" });
		}
	});

	app.get("/api/servers/:guildId/modmail/:threadId", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const thread = await guild.channels.fetch(req.params.threadId);
			if (thread?.isThread()) {
				const messages = await thread.messages.fetch({ limit: 50 });
				res.json(messages.map(m => ({
					id: m.id,
					author: m.author.username,
					content: m.content,
					timestamp: m.createdAt.toISOString()
				})).reverse());
			} else {
				res.status(404).json({ status: "error", message: "Thread not found" });
			}
		} catch (error) {
			Logger.error(`Failed to fetch modmail messages: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to fetch modmail messages" });
		}
	});

	app.post("/api/servers/:guildId/modmail/:threadId/reply", async (req, res) => {
		const { content } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const thread = await guild.channels.fetch(req.params.threadId);
			if (thread?.isThread()) {
				await thread.send(content);
				
				const { PrivateDmThread } = await import("./src/mongo/schemas/PrivateDmThread.js");
				const t = await PrivateDmThread.findOne({ threadId: req.params.threadId });
				if (t) {
					const user = await client.users.fetch(t.userId);
					await user.send(`**Reply from staff:**\n${content}`).catch(() => {});
				}
				
				res.json({ status: "success" });
			} else {
				res.status(404).json({ status: "error", message: "Thread not found" });
			}
		} catch (error) {
			Logger.error(`Failed to reply to modmail: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to reply to modmail" });
		}
	});

	app.post("/api/servers/:guildId/modmail/:threadId/close", async (req, res) => {
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const thread = await guild.channels.fetch(req.params.threadId);
			if (thread?.isThread()) {
				await thread.setArchived(true, "Closed via dashboard");
				
				const { PrivateDmThread } = await import("./src/mongo/schemas/PrivateDmThread.js");
				const t = await PrivateDmThread.findOne({ threadId: req.params.threadId });
				if (t) {
					const user = await client.users.fetch(t.userId);
					await user.send("**Modmail thread closed.**").catch(() => {});
					await PrivateDmThread.deleteOne({ threadId: req.params.threadId });
				}
				
				res.json({ status: "success" });
			} else {
				res.status(404).json({ status: "error", message: "Thread not found" });
			}
		} catch (error) {
			Logger.error(`Failed to close modmail: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to close modmail" });
		}
	});

	app.post("/api/guilds/:guildId/members/:memberId/action", async (req, res) => {
		const { action, value, reason } = req.body;
		try {
			const guild = await client.guilds.fetch(req.params.guildId);
			const member = await guild.members.fetch(req.params.memberId);
			
			switch (action) {
				case 'kick':
					await member.kick(reason);
					break;
				case 'ban':
					await member.ban({ reason });
					break;
				case 'warn':
					await member.send(`You have been warned in ${guild.name}. Reason: ${reason || 'No reason provided'}`).catch(() => {});
					addLog({
						id: Date.now().toString() + Math.random().toString(),
						guildId: guild.id,
						channelId: 'system',
						channelName: 'system',
						userId: member.id,
						username: member.user.username,
						action: 'WARN',
						content: `Reason: ${reason || 'No reason provided'}`,
						timestamp: Date.now()
					});
					break;
				case 'timeout':
					await member.timeout(value * 60 * 1000, reason);
					break;
			}
			res.json({ status: "success" });
		} catch (error) {
			Logger.error(`Failed to perform action ${action}: ${error}`);
			res.status(500).json({ status: "error", message: `Failed to perform action ${action}` });
		}
	});

	app.post("/api/sync-commands", async (req, res) => {
		try {
			await syncCommands(client as DiscordClient<true>);
			res.json({ status: "success" });
		} catch (error) {
			Logger.error(`Failed to sync commands: ${error}`);
			res.status(500).json({ status: "error", message: "Failed to sync commands" });
		}
	});

	app.post("/api/restart-bot", async (req, res) => {
		Logger.info("Restarting bot...");
		res.json({ status: "success" });
		process.exit(1); // Exit process to trigger container restart
	});

	// Vite middleware for development
	const distPath = path.join(process.cwd(), 'dist');
	const isProd = process.env.NODE_ENV === "production" || fs.existsSync(path.join(distPath, 'index.html'));
	console.log('isProd:', isProd, 'NODE_ENV:', process.env.NODE_ENV);
	
	if (!isProd) {
		const { createServer: createViteServer } = await import("vite");
		const vite = await createViteServer({
			server: { middlewareMode: true },
			appType: "spa",
		});
		app.use(vite.middlewares);
	} else {
		app.use(express.static(distPath));
		app.use((req, res) => {
			res.sendFile(path.join(distPath, 'index.html'));
		});
	}

	app.listen(PORT, "0.0.0.0", () => {
		Logger.info(`Web server running on port ${PORT}`);
	});

	return app;
}

const app = await startServer();

redis.on("error", Logger.error);
await initRedis();

try {
	const token = process.env.BOT_TOKEN;
	if (!token) {
		Logger.warn("BOT_TOKEN is missing. Bot will not start.");
	} else {
		await registerCommands(client);

		const mongoUrl = process.env.MONGO_URL || "mongodb+srv://tarekjasmine243_db_user:dpzAWsbnSgnMl1ZI@cluster0.xssdxpw.mongodb.net/?appName=Cluster0";
		if (mongoUrl) {
			try {
				await mongo.connect(mongoUrl, {
					retryWrites: true,
					writeConcern: {
						w: "majority",
					},
					dbName: "r-igcse-bot",
					serverSelectionTimeoutMS: 5000,
				});
				Logger.info("Connected to MongoDB.");
			} catch (err) {
				Logger.error(`Failed to connect to MongoDB: ${err}`);
			}
		} else {
			Logger.warn("MONGO_URL is missing. Some features may not work.");
		}

		await registerEvents(client);
		await client.login(token);
	}
} catch (error) {
	Logger.error(`Failed to start bot: ${error}`);
}

process.on("uncaughtException", (error) => {
	Logger.error(`Uncaught Exception: ${error} | Stack: ${error.stack}`);
});

process.on("unhandledRejection", (error) => {
	Logger.error(
		`Unhandled Rejection: ${error} | Stack: ${error instanceof Error ? error.stack : "Unknown"}`,
	);
});
