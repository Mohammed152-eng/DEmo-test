import express from 'express';

const app = express();
app.get('*all', (req, res) => {
  res.send('matched *all: ' + req.path);
});

app.listen(3002, () => {
  console.log('listening on 3002');
});