import express from 'express';

const app = express();
app.get('*all', (req, res) => {
  res.sendFile('/nonexistent/file.html');
});

app.listen(3001, () => {
  console.log('listening');
});
