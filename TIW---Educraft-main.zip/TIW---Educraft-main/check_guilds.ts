import "dotenv/config";
import { Client, GatewayIntentBits, Routes } from "discord.js";

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.on("ready", async () => {
  console.log(`Logged in as ${client.user?.tag}`);
  console.log(`Bot is in ${client.guilds.cache.size} guilds:`);
  for (const g of client.guilds.cache.values()) {
    console.log(`- ${g.name} (${g.id})`);
  }
  console.log(`MAIN_GUILD_ID from env: ${process.env.MAIN_GUILD_ID}`);
  
  try {
    const globalCommands = await client.rest.get(Routes.applicationCommands(client.application?.id ?? ''));
    console.log(`Global commands: ${(globalCommands as unknown[]).length}`);
  } catch (e) {
    console.error(`Global commands error: ${e}`);
  }

  try {
    if (process.env.MAIN_GUILD_ID) {
      const guildCommands = await client.rest.get(Routes.applicationGuildCommands(client.application?.id ?? '', process.env.MAIN_GUILD_ID));
      console.log(`Guild commands: ${(guildCommands as unknown[]).length}`);
    }
  } catch (e) {
    console.error(`Guild commands error: ${e}`);
  }

  process.exit(0);
});

client.login(process.env.BOT_TOKEN);
