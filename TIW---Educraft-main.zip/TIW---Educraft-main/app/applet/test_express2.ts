import express from 'express';
const app = express();
app.get('*all', (req, res) => res.send('ok'));
app.listen(3001, () => {
  fetch('http://localhost:3001/').then(r => r.text()).then(console.log);
  fetch('http://localhost:3001/foo').then(r => r.text()).then(console.log);
  setTimeout(() => process.exit(0), 1000);
});
