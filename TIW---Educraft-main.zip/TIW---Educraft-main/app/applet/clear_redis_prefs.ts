import { redis } from "../../src/redis/index.ts";

async function test() {
  await redis.connect();
  const keys = await redis.keys("GuildPreferences:*");
  for (const key of keys) {
    await redis.del(key);
    console.log("Deleted", key);
  }
  process.exit(0);
}
test();
