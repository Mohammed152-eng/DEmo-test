import { tyAliases, ywAliases } from "./src/data";

const content = "tysm";
const match = tyAliases.some((alias) =>
    new RegExp(`\\b${alias}\\b`, "gi").test(content)
);
console.log("Match tysm:", match);

const content2 = "ty";
const match2 = tyAliases.some((alias) =>
    new RegExp(`\\b${alias}\\b`, "gi").test(content2)
);
console.log("Match ty:", match2);

const content3 = "thank you";
const match3 = tyAliases.some((alias) =>
    new RegExp(`\\b${alias}\\b`, "gi").test(content3)
);
console.log("Match thank you:", match3);

const content4 = "np";
const match4 = ywAliases.some((alias) =>
    new RegExp(`\\b${alias}\\b`, "gi").test(content4)
);
console.log("Match np:", match4);
