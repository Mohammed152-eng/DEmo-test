import mongoose from "mongoose";

async function test() {
  await mongoose.connect("mongodb+srv://tarekjasmine243_db_user:dpzAWsbnSgnMl1ZI@cluster0.xssdxpw.mongodb.net/?appName=Cluster0", {
    dbName: "test"
  });
  const db = mongoose.connection.db;
  const collections = await db.listCollections().toArray();
  console.log("Collections in test:", collections.map(c => c.name));
  
  const prefs = await db.collection("guildpreferences").find({}).toArray();
  console.log("Prefs in test:", prefs);
  process.exit(0);
}
test();
