import { exec } from 'child_process';
const child = exec('npx tsx src/index.ts', { env: { ...process.env, NODE_ENV: 'production' } });
child.stdout.on('data', console.log);
child.stderr.on('data', console.error);
setTimeout(() => {
  fetch('http://localhost:3000/').then(r => {
    console.log('Status:', r.status);
    return r.text();
  }).then(console.log).catch(console.error);
  setTimeout(() => process.exit(0), 2000);
}, 5000);
