import mongoose from "mongoose";
import { GuildPreferences } from "../../src/mongo/schemas/GuildPreferences.ts";

async function test() {
  await mongoose.connect("mongodb+srv://tarekjasmine243_db_user:dpzAWsbnSgnMl1ZI@cluster0.xssdxpw.mongodb.net/?appName=Cluster0", {
    dbName: "r-igcse-bot"
  });
  
  const guildId = "1192829849916690502";
  
  await GuildPreferences.updateOne(
    { guildId },
    {
      $set: {
        repEnabled: true,
        repDisabledChannelIds: []
      }
    },
    { upsert: true }
  );
  
  console.log("Upserted GuildPreferences for guild", guildId);
  process.exit(0);
}
test();
