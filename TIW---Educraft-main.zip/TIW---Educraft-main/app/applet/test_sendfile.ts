import express from 'express';
const app = express();
app.get('/', (req, res) => {
  res.sendFile('/does/not/exist.html');
});
app.listen(3001, () => {
  fetch('http://localhost:3001/').then(r => r.text()).then(console.log);
  setTimeout(() => process.exit(0), 1000);
});
