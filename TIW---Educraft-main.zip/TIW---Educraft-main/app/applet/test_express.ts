import express from 'express';

const app = express();
app.get('*all', (req, res) => {
  res.send('matched *all');
});
app.get('/*', (req, res) => {
  res.send('matched /*');
});

app.listen(3001, () => {
  console.log('listening');
});
