import mongoose from "mongoose";

async function test() {
  await mongoose.connect("mongodb+srv://tarekjasmine243_db_user:dpzAWsbnSgnMl1ZI@cluster0.xssdxpw.mongodb.net/?appName=Cluster0", {
    dbName: "r-igcse-bot"
  });
  const db = mongoose.connection.db;
  const repData = await db.collection("reputationdatas").find({}).toArray();
  console.log("ReputationData:", repData);
  const rep = await db.collection("reputations").find({}).toArray();
  console.log("Reputation:", rep);
  process.exit(0);
}
test();
