import { redis } from "../../src/redis/index.ts";

async function test() {
  await redis.connect();
  const keys = await redis.keys("GuildPreferences:*");
  console.log("Keys:", keys);
  for (const key of keys) {
    const val = await redis.hGetAll(key);
    console.log(`Key ${key}:`, val);
  }
  process.exit(0);
}
test();
