import { connect } from "mongoose";
import { GuildPreferences } from "./src/mongo/schemas/GuildPreferences.js";
import { config } from "dotenv";
config();

async function check() {
  await connect(process.env.MONGO_URL as string);
  const prefs = await GuildPreferences.findOne({ guildId: "1288341311958679593" });
  console.log("Prefs:", prefs);
  process.exit(0);
}
check();