import { redis } from "../../src/redis/index.ts";

async function test() {
  await redis.connect();
  await redis.flushAll();
  console.log("Flushed all redis data");
  process.exit(0);
}
test();
