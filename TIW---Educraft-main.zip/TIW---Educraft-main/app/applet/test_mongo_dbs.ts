import mongoose from "mongoose";

async function test() {
  await mongoose.connect("mongodb+srv://tarekjasmine243_db_user:dpzAWsbnSgnMl1ZI@cluster0.xssdxpw.mongodb.net/?appName=Cluster0");
  const adminDb = mongoose.connection.db.admin();
  const dbs = await adminDb.listDatabases();
  console.log("Databases:", dbs.databases.map(d => d.name));
  process.exit(0);
}
test();
