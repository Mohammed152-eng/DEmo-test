import mongoose from "mongoose";

async function test() {
  await mongoose.connect("mongodb+srv://tarekjasmine243_db_user:dpzAWsbnSgnMl1ZI@cluster0.xssdxpw.mongodb.net/?appName=Cluster0", {
    dbName: "r-igcse-bot"
  });
  const db = mongoose.connection.db;
  const prefs = await db.collection("guildpreferences").find({}).toArray();
  console.log("Prefs:", prefs);
  process.exit(0);
}
test();
