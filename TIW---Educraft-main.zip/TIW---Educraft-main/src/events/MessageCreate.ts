import { formatMessage } from "@/commands/study/Keyword";
import Select from "@/components/Select";
import Buttons from "@/components/practice/views/Buttons";
import { botYwResponses, tyAliases, ywAliases } from "@/data";
import { PrivateDmThread, Reputation, type IGuildPreferences } from "@/mongo";
import { DmGuildPreference } from "@/mongo/schemas/DmGuildPreference";
import {
	GuildPreferencesCache,
	KeywordCache,
	StickyMessageCache,
	redis,
} from "@/redis";
import type { ICachedStickyMessage } from "@/redis/schemas/StickyMessage";
import { logToChannel } from "@/utils/Logger";
import sendDm from "@/utils/sendDm";
import { Logger } from "@discordforge/logger";

const STAFF_MESSAGE_PREFIX_REGEX = /^\/\/!?/;

import {
	type APIEmbed,
	ActionRowBuilder,
	type ButtonBuilder,
	Colors,
	EmbedBuilder,
	Events,
	ForumChannel,
	type GuildMember,
	type Message,
	type MessageCreateOptions,
	StringSelectMenuOptionBuilder,
	ThreadChannel,
	type User,
} from "discord.js";
import { v4 as uuidv4 } from "uuid";
import type { DiscordClient } from "../registry/DiscordClient";
import BaseEvent from "../registry/Structure/BaseEvent";
import { syncCommands } from "@/registry";
import { isBotDev } from "@/utils/isBotDev";
import { ReputationData } from "@/mongo/schemas/ReputationData";

const stickyCounter: Record<string, number> = {};

export default class MessageCreateEvent extends BaseEvent {
	constructor() {
		super(Events.MessageCreate);
	}

	async execute(client: DiscordClient<true>, message: Message) {
		if (message.author.bot) return;
		if (message.system) return;
		if (message.content === "!sync_commands") {
			if (!(await isBotDev(client, message.author.id))) {
				return;
			}

			await syncCommands(client)
				.then(() => {
					Logger.info(
						`Synced application commands globally (by ${message.author.displayName})`,
					);
					message.reply("Succesfully synced commands.");
				})
				.catch((e) => {
					Logger.error(
						`Error syncing application commands globally (by ${message.author.displayName}): ${e}`,
					);
					message.reply("Error syncing commands.");
				});

			return;
		}

		if (message.inGuild()) {
			const keyword = message.content.trim().toLowerCase();
			const entry = await KeywordCache.get(message.guildId, keyword);
			if (entry.response) {
				const messageOptions = (await formatMessage(
					message,
					entry.response,
					false,
					keyword,
					entry.imageLink,
				)) as MessageCreateOptions;
				messageOptions.flags = undefined;
				await message.channel.send(messageOptions);
			}

			const guildPreferences = await GuildPreferencesCache.get(
				message.guild.id,
			);

			if (!guildPreferences) return;

			if (
				guildPreferences.countingChannelId &&
				message.channel.id === guildPreferences.countingChannelId
			) {
				const countingChannel = message.guild.channels.cache.get(
					guildPreferences.countingChannelId,
				);

				if (!countingChannel || !countingChannel.isTextBased()) return;

				const lastMessage = [
					...(
						await countingChannel.messages.fetch({
							before: message.id,
							limit: 1,
						})
					).values(),
				][0];

				if (
					((!lastMessage && message.content === "1") ||
						(lastMessage &&
							`${Number.parseInt(lastMessage.content) + 1}` ===
								message.content)) &&
					lastMessage.author.id !== message.author.id
				)
					message.react("✅");
				else message.delete();
			}

			if (guildPreferences.repEnabled)
				this.handleRep(
					client,
					message,
					guildPreferences.repDisabledChannelIds,
				).catch((e) => Logger.error(`[MessageCreate] Error in handleRep: ${e}`));

			if (client.stickyChannelIds.includes(message.channelId)) {
				if (
					stickyCounter[message.channelId] === 4 &&
					stickyCounter[message.channelId] >= 4
				) {
					this.handleStickyMessages(message).catch((e) =>
						Logger.error(`Error at handleStickyMessages: ${e}`),
					);
					stickyCounter[message.channelId] = 0;
				} else {
					stickyCounter[message.channelId] = ((x: number) =>
						(Number.isNaN(x) ? 0 : x) + 1)(
						stickyCounter[message.channelId],
					);
				}
			}

			if (message.channelId === guildPreferences.modmailCreateChannelId) {
				if (
					!guildPreferences.modmailThreadsChannelId ||
					!guildPreferences.modmailCreateChannelId
				) {
					await message.reply(
						"Modmail is not set up in this server.",
					);
					return;
				}

				const member = await message.guild.members
					.fetch(message.content)
					.catch(async () => {
						await message.reply("Invalid User ID");
						return;
					});

				if (!member) return;

				const res = await PrivateDmThread.findOne({
					userId: member.id,
					guildId: message.guild.id,
				});

				if (res) {
					const thread = await message.guild.channels
						.fetch(res.threadId)
						.catch(async () => {
							await PrivateDmThread.deleteMany({
								userId: member.id,
								guildId: message.guild.id,
							});
							await message.reply(
								"Thread not found (could've been manually deleted), please try again to create a new thread.",
							);
							return;
						});

					if (thread) {
						await message.reply(
							`DM Thread with this user already exists: <#${thread.id}>`,
						);

						return;
					}
				}

				const threadsChannel = message.guild.channels.cache.get(
					guildPreferences.modmailThreadsChannelId,
				);

				if (
					!threadsChannel ||
					!(threadsChannel instanceof ForumChannel)
				) {
					await message.reply(
						`Threads channel (${threadsChannel}) should be a forum channel.`,
					);
					return;
				}

				try {
					const newThread = await threadsChannel.threads.create({
						name: `${member.user.tag} (${member.id})`,
						message: {
							content: `Username: \`${member.user.tag}\`\nUser ID: \`${member.id}\``,
						},
					});

					await PrivateDmThread.create({
						userId: member.id,
						threadId: newThread.id,
						guildId: message.guild.id,
					});

					await message.reply(
						`Created dm thread for user at <#${newThread.id}>.`,
					);
				} catch (error) {
					await message.reply("Unable to create thread");

					client.log(
						error,
						"Create DM Thread",
						`**Channel:** <#${message.channel?.id}>
							**User:** <@${message.author.id}>
							**Guild:** ${message.guild.name} (${message.guildId})\n`,
					);
				}
			}
			if (
				message.channel instanceof ThreadChannel &&
				message.channel.parentId ===
					guildPreferences.modmailThreadsChannelId
			) {
				this.handleModMailReply(client, message as Message<true>);
			}
		} else this.handleModMail(client, message as Message<false>);
	}

	private async handleModMail(
		client: DiscordClient<true>,
		message: Message<false>,
	) {
		let guildId = "";

		const dmPreference = await DmGuildPreference.findOne({
			userId: message.author.id,
		});

		if (dmPreference) guildId = dmPreference.guildId;
		else {
			const guilds = client.guilds.cache.filter((guild) =>
				guild.members.cache.has(message.author.id),
			);
			if (guilds.size === 0) {
				await message.author.send(
					"Hey there, please send a message in the server you're trying to contact and then try again.",
				);
				return;
			}
			const selectCustomId = uuidv4();
			const guildSelect = new Select(
				"guildSelect",
				"Select a server",
				guilds.map((guild) => {
					return new StringSelectMenuOptionBuilder()
						.setLabel(guild.name)
						.setValue(guild.id);
				}),
				1,
				`${selectCustomId}_0`,
			);

			const row = new ActionRowBuilder<Select>().addComponents(
				guildSelect,
			);

			const selectInteraction = await message.author.send({
				content: `Welcome to Modmail! Please select a server to contact using the dropdown menu below.
If you don't see the server you're looking for, please send a message in that server and try again.

To change the server you're contacting, use the \`/swap\` command`,
				components: [
					row,
					new Buttons(
						selectCustomId,
					) as ActionRowBuilder<ButtonBuilder>,
				],
			});

			const guildResponse = await guildSelect.waitForResponse(
				`${selectCustomId}_0`,
				selectInteraction,
				selectInteraction,
				true,
			);

			if (!guildResponse || guildResponse === "Timed out") return;
			const guild = client.guilds.cache.get(guildResponse[0]);

			if (!guild) {
				await selectInteraction.edit({
					content: "Invalid Server",
					components: [],
				});
				return;
			}

			await selectInteraction.edit({
				content: `Server ${guild.name} selected.`,
				components: [],
			});

			guildId = guildResponse[0];

			await DmGuildPreference.create({
				userId: message.author.id,
				guildId: guildId,
			});
		}

		const guild = client.guilds.cache.get(guildId);
		if (!guild) return;

		const guildPreferences = await GuildPreferencesCache.get(guildId);

		if (!guildPreferences || !guildPreferences.modmailThreadsChannelId) {
			await message.author.send(
				`Modmail is not set up in **${guild.name}**`,
			);
			return;
		}

		const channel = guild.channels.cache.get(
			guildPreferences.modmailThreadsChannelId,
		);

		if (!channel || !(channel instanceof ForumChannel)) {
			await message.author.send(
				`Unable to find the modmail channel in **${guild.name}**. Please contact the server staff.`,
			);
			return;
		}
		const res = await PrivateDmThread.findOne({
			userId: message.author.id,
			guildId,
		});

		let thread: ThreadChannel;

		if (res)
			thread = (await channel.threads.fetch(
				res.threadId,
			)) as ThreadChannel;
		else {
			thread = await channel.threads.create({
				name: `${message.author.username} (${message.author.id})`,
				message: {
					content: `Username: \`${message.author.tag}\`\nUser ID: \`${message.author.id}\``,
				},
			});
			await PrivateDmThread.create({
				userId: message.author.id,
				threadId: thread.id,
				guildId,
			});
		}

		const embed = new EmbedBuilder()
			.setTitle("New DM Received")
			.setAuthor({
				name: message.author.username,
				iconURL: message.author.displayAvatarURL(),
			})
			.setDescription(message.content || "No content")
			.setTimestamp(message.createdTimestamp)
			.setColor(Colors.Red);

		if (message.attachments.size > 0) {
			embed.addFields({
				name: "Attachments",
				value: message.attachments
					.map(
						(attachment) =>
							`[${attachment.name}](${attachment.url})`,
					)
					.join("\n"),
			});
		}

		if (guildPreferences.modmailLogsChannelId) {
			logToChannel(guild, guildPreferences.modmailLogsChannelId, {
				embeds: [
					{
						title: "New DM Received",
						description: `**User:** ${message.author.tag} (${message.author.id})\n**Thread:** <#${thread.id}>`,
						color: Colors.Purple,
						timestamp: new Date().toISOString(),
					},
				],
			});
		}

		thread.send({
			embeds: [embed],
		});

		await message.react("✅");
	}

	private async handleModMailDelete(
		client: DiscordClient<true>,
		user: GuildMember | User,
		numDelete = 1,
	) {
		const channel = await user.createDM();
		const messages = (await channel.messages.fetch({ limit: 100 })).filter(
			(m) => m.author.id === client.user.id,
		);
		for (const msg of messages) {
			if (numDelete <= 0) break;
			// biome-ignore lint/style/noParameterAssign: cuz
			numDelete--;
			await msg[1].delete();
		}
	}

	private async handleModMailReply(
		client: DiscordClient<true>,
		message: Message<true>,
	) {
		if (
			!message.content.startsWith("//") &&
			!message.content.startsWith("!!")
		) {
			await message.react("👀");
			return;
		}

		const dmThread = await PrivateDmThread.findOne({
			threadId: message.channel.id,
		});

		if (!dmThread) {
			await message.reply("Unable to find the user for this thread.");
			return;
		}

		const member = await message.guild.members
			.fetch(dmThread.userId)
			.catch(() => null);
		const user =
			member ??
			(await client.users.fetch(dmThread.userId).catch(() => null));
		if (!user) {
			await message.reply("Unable to find the user.");
			return;
		}

		if (message.content.startsWith("!!")) {
			const fullCommand = message.content.split(" ");
			const command = fullCommand[1];
			const args = fullCommand.slice(2);

			if (command === "delete") {
				let numDelete: number;
				if (args && args.length > 0) {
					numDelete = Number(args[0]);
				} else {
					numDelete = 1;
				}
				this.handleModMailDelete(client, user, numDelete);
				await message.react("☑");
			}
		} else {
			const embed = new EmbedBuilder()
				.setTitle(`Message from ${message.guild.name} Staff`)
				.setAuthor({
					name: message.content.startsWith("//!")
						? `${message.guild.name} Moderators`
						: message.author.username,
					iconURL: message.content.startsWith("//!")
						? message.guild.iconURL() || undefined
						: message.author.displayAvatarURL(),
				})
				.setDescription(
					message.content?.replace(STAFF_MESSAGE_PREFIX_REGEX, "").trim() ||
						"No content",
				)
				.setTimestamp(message.createdTimestamp)
				.setColor(Colors.Green);

			if (message.attachments.size > 0) {
				embed.addFields({
					name: "Attachments",
					value: message.attachments
						.map(
							(attachment) =>
								`[${attachment.name}](${attachment.url})`,
						)
						.join("\n"),
				});
			}

			if (member) {
				await sendDm(member, {
					embeds: [embed],
				});
			} else {
				await user.send({
					embeds: [embed],
				});
			}

			await message.react(message.content.startsWith("//!") ? "☑" : "✅");
		}
	}

	private async handleRep(
		client: DiscordClient<true>,
		message: Message<true>,
		repDisabledChannels: string[],
	) {
		const channelId =
			(message.channel.isThread() && !message.channel.isThreadOnly()
				? message.channel.parentId
				: message.channelId) ?? "";

		if (repDisabledChannels?.includes(channelId)) return;

		// Distributed lock to prevent multiple instances from processing the same message
		const lockKey = `rep_lock:${message.id}`;
		const isLocked = await redis.set(lockKey, "1", { NX: true, EX: 60 }).catch((e) => {
			Logger.error(`[handleRep] Redis lock error: ${e}`);
			return "OK"; // Proceed if Redis fails, to not break the feature completely
		});
		if (!isLocked) return; // Already processed this message!

		const { users, errors } = await this.getReppedUsers(client, message);
		const repMessages: string[] = [];

		// Limit to 1 rep per message as requested
		const targetUser = users[0];

		if (targetUser) {
			if (targetUser.id === client.user.id) {
				repMessages.push(
					botYwResponses[
						Math.floor(Math.random() * botYwResponses.length)
					],
				);
			} else {
				const member = await message.guild.members.fetch(targetUser.id).catch((e) => {
					Logger.error(`[handleRep] Error fetching member: ${e}`);
					return null;
				});

				if (member) {
					// Cooldown check: prevent multiple instances or spamming from giving multiple reps
					// within a 1-minute window
					const oneMinuteAgo = new Date(Date.now() - 60 * 1000);
					const recentRep = await ReputationData.findOne({
						reppedUser: member.id,
						reppedBy: message.author.id,
						when: { $gte: oneMinuteAgo },
					});

					if (!recentRep) {
						// Atomic check to ensure this exact message hasn't already given rep to this user
						const existingRepData = await ReputationData.findOneAndUpdate(
							{
								messageId: message.id,
								reppedUser: member.id,
							},
							{
								$setOnInsert: {
									guildId: message.guildId,
									channelId: message.channelId,
									when: new Date(),
									reppedBy: message.author.id,
									repNumber: 0, // Placeholder
								},
							},
							{ upsert: true, new: false },
						);

						if (!existingRepData) {
							let rep = 1;

							const res = await Reputation.findOneAndUpdate(
								{
									guildId: message.guildId,
									userId: member.id,
								},
								{
									$inc: {
										rep: 1,
									},
								},
							);

							if (res) rep = res.rep + 1;
							else
								await Reputation.create({
									guildId: message.guildId,
									userId: member.id,
									rep: 1,
								});

							await ReputationData.updateOne(
								{ messageId: message.id, reppedUser: member.id },
								{ $set: { repNumber: rep } }
							).catch((e) =>
								Logger.error(`Error updating ReputationData repNumber: ${e}`),
							);

							let content = `Gave +1 Rep to <@${targetUser.id}> (${rep})`;

							const milestones = [
								{ rep: 50, roleName: "Rookie", emoji: "<:rookie:1489359176923611217>", iconUrl: "https://cdn.discordapp.com/emojis/1489359176923611217.png?size=64", extra: "" },
								{ rep: 100, roleName: "Rising Star", emoji: "⭐", iconUrl: null, extra: "\nYou have unlocked nickname color customization! Use `/customcolor` to set it." },
								{ rep: 500, roleName: "Contributor", emoji: "🌟", iconUrl: null, extra: "\nYou have unlocked the emoji perk!" },
								{ rep: 750, roleName: "Veteran", emoji: "<:veteran:1489359269206822983>", iconUrl: "https://cdn.discordapp.com/emojis/1489359269206822983.png?size=64", extra: "\nYou now have a high chance to be nominated as Chat Moderator!" },
								{ rep: 1000, roleName: "Elite Helper", emoji: "<:elite:1351197724246278170>", iconUrl: "https://cdn.discordapp.com/emojis/1351197724246278170.png?size=64", extra: "\nYou have unlocked your own custom role! Contact an admin to claim it." }
							];

							const milestone = milestones.find((m) => m.rep === rep);

							if (milestone) {
								let role = message.guild.roles.cache.find(
									(x) => x.name === milestone.roleName,
								);

								const isUnicodeEmoji = milestone.emoji === "⭐" || milestone.emoji === "🌟";
								const canSetRoleIcon = message.guild.features.includes('ROLE_ICONS');
								
								const iconUrl = milestone.iconUrl;

								const botHighestRole = message.guild.members.me?.roles.highest;
								const userColoredRoles = member.roles.cache.filter(r => r.color !== 0 && (!role || r.id !== role.id));
								const highestUserColorRole = userColoredRoles.sort((a, b) => b.position - a.position).first();
								
								let targetPosition = highestUserColorRole ? highestUserColorRole.position + 1 : 1;
								if (botHighestRole && targetPosition >= botHighestRole.position) {
									targetPosition = botHighestRole.position - 1;
								}

								let targetColor: `#${string}` | undefined = undefined;
								if (milestone.rep === 100) targetColor = "#FF0000";
								else if (milestone.rep === 500) targetColor = "#00FF00";
								else if (milestone.rep === 1000) targetColor = "#00FFFF";

								if (!role) {
									try {
										role = await message.guild.roles.create({
											name: milestone.roleName,
											reason: `Reached ${milestone.rep} reputation`,
											unicodeEmoji: (isUnicodeEmoji && canSetRoleIcon) ? milestone.emoji : null,
											icon: (iconUrl && canSetRoleIcon) ? iconUrl : null,
											color: targetColor,
											position: targetPosition > 0 ? targetPosition : 1,
										});
									} catch (e) {
										Logger.error(`Failed to create role ${milestone.roleName}: ${e}`);
									}
								} else {
									try {
										const updates: import("discord.js").RoleEditOptions = {};
										if (canSetRoleIcon) {
											if (isUnicodeEmoji && role.unicodeEmoji !== milestone.emoji) {
												updates.unicodeEmoji = milestone.emoji;
											} else if (iconUrl && !role.icon) {
												updates.icon = iconUrl;
											}
										}
										if (targetColor && role.hexColor.toUpperCase() !== targetColor) {
											updates.color = targetColor;
										}
										
										if (role.position < targetPosition) {
											updates.position = targetPosition > 0 ? targetPosition : 1;
										}
										
										if (Object.keys(updates).length > 0) {
											await role.edit(updates);
										}
									} catch (e) {
										Logger.error(`Failed to update role for ${milestone.roleName}: ${e}`);
									}
								}

								if (role) {
									content += `\nWelcome to the ${role.name} ${milestone.emoji}${milestone.extra}`;
									await member.roles.add(role).catch(() => {});
									
									// Remove custom color roles so the milestone color shows
									if (targetColor) {
										const customColorRoles = member.roles.cache.filter(r => 
											(r.members.size === 1 && r.color !== 0 && !r.name.startsWith('Booster-')) || 
											r.name.startsWith('Color-')
										);
										if (customColorRoles.size > 0) {
											await member.roles.remove(customColorRoles).catch(() => {});
										}
									}
								} else {
									content += `\nYou reached the ${milestone.roleName} milestone! ${milestone.emoji}${milestone.extra}`;
								}

								// Append emoji to nickname if it's a star
								if (isUnicodeEmoji) {
									try {
										const currentName = member.displayName;
										// Remove old stars if present to avoid duplication
										const cleanName = currentName.replace(/ ⭐| 🌟/g, '');
										if (member.manageable) {
											await member.setNickname(`${cleanName} ${milestone.emoji}`);
										}
									} catch (e) {
										Logger.error(`Failed to set nickname for ${member.user.tag}: ${e}`);
									}
								}
							}

							repMessages.push(content);
						}
					} else {
						errors.push("Please wait a minute before giving rep to this user again!");
					}
				}
			}
		}

		// Consolidate all messages (successes and errors) into one reply
		const allMessages = [...new Set([...errors, ...repMessages])];
		if (allMessages.length > 0) {
			message.reply({
				content: allMessages.join("\n"),
				allowedMentions: { repliedUser: false },
			}).catch((e) => Logger.error(`Error sending rep response: ${e}`));
		}
	}

	private async getReppedUsers(
		client: DiscordClient<true>,
		message: Message,
		depth = 0,
	): Promise<{ users: User[]; errors: string[] }> {
		const users = new Set<User>();
		const errors = new Set<string>();

		// Prevent deep recursion
		if (depth > 1) return { users: [], errors: [] };

		if (
			tyAliases.some((alias) =>
				new RegExp(`\\b${alias}\\b`, "gi").test(message.content),
			)
		) {
			for (const user of message.mentions.users.values()) {
				if (message.author.id === user.id) {
					errors.add("You can't rep yourself dummy!");
				} else if (user.bot && user.id !== client.user.id) {
					errors.add("Uh-oh, you can't rep a bot");
				} else {
					users.add(user);
				}
			}

			if (message.mentions.repliedUser) {
				const repliedUser = message.mentions.repliedUser;
				if (message.author.id === repliedUser.id) {
					errors.add("You can't rep yourself dummy!");
				} else if (repliedUser.bot && repliedUser.id !== client.user.id) {
					errors.add("Uh-oh, you can't rep a bot");
				} else {
					users.add(repliedUser);
				}
			} else if (message.reference) {
				const reference = await message.fetchReference().catch((e) => {
					Logger.error(`[getReppedUsers] Error fetching reference: ${e}`);
					return null;
				});

				if (reference) {
					if (message.author.id === reference.author.id) {
						errors.add("You can't rep yourself dummy!");
					} else if (reference.author.bot && reference.author.id !== client.user.id) {
						errors.add("Uh-oh, you can't rep a bot");
					} else {
						users.add(reference.author);
					}
				} else {
					errors.add("I couldn't fetch the message you replied to! Make sure I have 'Read Message History' permissions in this channel.");
				}
			}
		} else if (
			message.reference &&
			ywAliases.some((alias) =>
				new RegExp(`\\b${alias}\\b`, "gi").test(message.content),
			)
		) {
			const reference = await message.fetchReference().catch((e) => {
				Logger.error(`[getReppedUsers] Error fetching reference for yw: ${e}`);
				return null;
			});

			if (reference) {
				if (reference.author.id === message.author.id) {
					errors.add("You can't rep yourself dummy!");
				} else if (reference.author.id === client.user.id) {
					// Bot was thanked, so it says "yw", but it shouldn't rep itself
					// This case is handled in handleRep if client.user.id is in users
					users.add(client.user);
				} else if (reference.author.bot) {
					errors.add("Uh-oh, you can't get rep from a bot");
				} else {
					const isThankYou = tyAliases.some((alias) =>
						new RegExp(`\\b${alias}\\b`, "gi").test(reference.content),
					);
					if (isThankYou) {
						const { users: referenceRepped } = await this.getReppedUsers(
							client,
							reference,
							depth + 1,
						);

						if (!referenceRepped.some(u => u.id === message.author.id)) {
							users.add(message.author);
						}
					}
				}
			} else {
				errors.add("I couldn't fetch the message you replied to! Make sure I have 'Read Message History' permissions in this channel.");
			}
		}

		return { 
			users: Array.from(users), 
			errors: Array.from(errors) 
		};
	}

	private async handleStickyMessages(message: Message<true>) {
		const stickyMessages = (await StickyMessageCache.search()
			.where("channelId")
			.equals(message.channelId)
			.returnAll()
			.catch(() => [])) as ICachedStickyMessage[];

		for (const stickyMessage of stickyMessages) {
			if (stickyMessage.messageId) {
				await message.channel.messages
					.delete(stickyMessage.messageId)
					.catch(() => {});
			}

			const newSticky = await message.channel.send({
				content: ((x) => (x === "" ? undefined : x))(
					stickyMessage.message.content,
				),
				embeds: stickyMessage.message.embeds as APIEmbed[],
			});

			stickyMessage.messageId = newSticky.id;
			await StickyMessageCache.save(stickyMessage);
		}
	}
}
