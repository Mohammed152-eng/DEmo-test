import { Schema, model as createModel } from "mongoose";

export interface ICustomColorRole {
	guildId: string;
	userId: string;
	roleId: string;
}

const schema = new Schema<ICustomColorRole>({
	guildId: { type: String, required: true, unique: false },
	userId: { type: String, required: true, unique: false },
	roleId: { type: String, required: true, unique: false },
});

export const CustomColorRole = createModel<ICustomColorRole>("CustomColorRole", schema);
