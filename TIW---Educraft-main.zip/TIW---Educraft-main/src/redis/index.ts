import { createClient } from "redis";

import { ButtonInteractionRepository } from "./schemas/ButtonInteraction";
import { GuildPreferencesRepository } from "./schemas/GuildPreferences";
import { KeywordRepository } from "./schemas/Keyword";
import { PracticeQuestionRepository } from "./schemas/Question";
import { StickyMessageRepository } from "./schemas/StickyMessage";
import { ModPingRepository } from "./schemas/ModPing";
import { UserRepository } from "./schemas/User";

export const redis = createClient({
	url: process.env.REDIS_URL || "redis://default:ikw0FZh4vDJOaEkcqRfXjGGQkZsyjI0Y@redis-11403.c265.us-east-1-2.ec2.cloud.redislabs.com:11403",
});

export const GuildPreferencesCache = new GuildPreferencesRepository(redis);
export const StickyMessageCache = new StickyMessageRepository(redis);
export const ModPingCache = new ModPingRepository(redis);
export const PracticeQuestionCache = new PracticeQuestionRepository(redis);
export const UserCache = new UserRepository(redis);
export const ButtonInteractionCache = new ButtonInteractionRepository(redis);
export const KeywordCache = new KeywordRepository(redis);

export async function initRedis() {
	try {
		const redisUrl = process.env.REDIS_URL || "redis://default:ikw0FZh4vDJOaEkcqRfXjGGQkZsyjI0Y@redis-11403.c265.us-east-1-2.ec2.cloud.redislabs.com:11403";
		if (!redisUrl) {
			console.warn("REDIS_URL is missing. Redis features will not work.");
			return;
		}
		await redis.connect();
		await GuildPreferencesCache.createIndex();
		await StickyMessageCache.createIndex();
		await ModPingCache.createIndex();
		await PracticeQuestionCache.createIndex();
		await UserCache.createIndex();
		await ButtonInteractionCache.createIndex();
		await KeywordCache.createIndex();
		console.log("Connected to Redis.");
	} catch (error) {
		console.error("Failed to connect to Redis:", error);
	}
}
