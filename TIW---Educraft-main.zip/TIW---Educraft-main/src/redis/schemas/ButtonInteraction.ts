import {
	type Entity,
	type RedisConnection,
	Repository,
	Schema,
} from "redis-om";

export interface IButtonInteraction extends Entity {
	customId: string;
	messageId: string;
	guildId?: string;
	userHash?: string;
	userId?: string;
	questionAndAnswers?: string[];
}

export const ButtonInteraction = new Schema("ButtonInteraction", {
	customId: { type: "string" },
	messageId: { type: "string" },
	guildId: { type: "string" },
	userHash: { type: "string" },
	userId: { type: "string" },
	questionAndAnswers: { type: "string[]" },
});

export class ButtonInteractionRepository extends Repository {
	constructor(redis: RedisConnection) {
		super(ButtonInteraction, redis);
	}

	async get(customId: string): Promise<IButtonInteraction | null> {
		const button = (await this.fetch(customId)) as IButtonInteraction;
		if (!button.customId) return null;
		return button;
	}

	async set(customId: string, data: IButtonInteraction): Promise<void> {
		await this.save(customId, data);
	}

	async getAll(): Promise<IButtonInteraction[]> {
		return (await this.search().return.all()) as IButtonInteraction[];
	}
}
