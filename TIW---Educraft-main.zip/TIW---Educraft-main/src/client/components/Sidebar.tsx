import { NavLink } from 'react-router-dom';
import { 
  House, Settings, FileText, Terminal, Shield, 
  History, Ticket, Gavel, Lightbulb, CheckSquare,
  Code, Play, Camera, MessageSquare, Atom,
  type LucideIcon
} from 'lucide-react';
import clsx from 'clsx';

const NavItem = ({ to, icon: Icon, label, section }: { to: string, icon: LucideIcon, label: string, section?: boolean }) => (
  <NavLink
    to={to}
    className={({ isActive }) => clsx(
      "flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors",
      isActive 
        ? "bg-blue-600/20 text-blue-500" 
        : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
    )}
  >
    <Icon size={18} />
    <span className="font-medium text-sm">{label}</span>
  </NavLink>
);

const Section = ({ title }: { title: string }) => (
  <div className="px-4 mt-6 mb-2 text-xs font-bold tracking-wider text-slate-500 uppercase">
    {title}
  </div>
);

export default function Sidebar() {
  return (
    <aside className="w-64 bg-[#141621] border-r border-slate-800/50 flex flex-col h-full">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
          <Atom size={20} className="text-white" />
        </div>
        <div>
          <h1 className="font-bold text-white">TIW</h1>
          <p className="text-xs text-slate-400">Bot Dashboard</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-6 space-y-1">
        <Section title="Main" />
        <NavItem to="/" icon={House} label="Dashboard" />
      </div>
    </aside>
  );
}
