import { useState, useEffect, useRef, useCallback } from 'react';
import { Server, Users, Shield, Ban, AlertTriangle, Clock, Award, UserMinus, Trash2, Search, Activity, Settings, UserPlus, Zap, X, Mail, RefreshCw, Plus } from 'lucide-react';

function UserSelect({ 
  serverId,
  value, 
  onChange, 
  placeholder = "Search users..." 
}: { 
  serverId: string | null,
  value: string, 
  onChange: (val: string) => void,
  placeholder?: string
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState<{id: string, username: string, avatar: string, color?: string}[]>([]);
  const [loading, setLoading] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (!serverId) return;
    const delayDebounceFn = setTimeout(() => {
      setLoading(true);
      fetch(`/api/servers/${serverId}/users${search ? `?q=${encodeURIComponent(search)}` : ''}`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) setUsers(data);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }, 300);
    return () => clearTimeout(delayDebounceFn);
  }, [search, serverId]);

  const selectedUser = users.find(u => u.id === value);
  const displayValue = isOpen ? search : (selectedUser ? selectedUser.username : '');

  return (
    <div className="relative w-full" ref={wrapperRef}>
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder={selectedUser ? selectedUser.username : placeholder}
          value={displayValue}
          onChange={e => {
            setSearch(e.target.value);
            setIsOpen(true);
            if (e.target.value === '') onChange('');
          }}
          onFocus={() => {
            setIsOpen(true);
            setSearch('');
          }}
          className="pl-9 pr-8 py-2 bg-[#0f111a] border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-slate-500 w-full"
        />
        {value && (
          <button 
            type="button"
            onClick={() => { onChange(''); setSearch(''); }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
          >
            <X size={14} />
          </button>
        )}
      </div>
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-[#1a1d27] border border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto">
          {loading ? (
            <div className="p-3 text-sm text-slate-400 text-center">Loading...</div>
          ) : users.length === 0 ? (
            <div className="p-3 text-sm text-slate-400 text-center">No users found</div>
          ) : (
            users.map(u => (
              <button
                key={u.id}
                type="button"
                onClick={() => {
                  onChange(u.id);
                  setSearch('');
                  setIsOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 flex items-center gap-2"
              >
                <img src={u.avatar} alt="" className="w-5 h-5 rounded-full" />
                <span style={{ color: u.color || 'inherit' }}>{u.username}</span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  const [servers, setServers] = useState<{id: string, name: string, memberCount: number}[]>([]);
  const [selectedServer, setSelectedServer] = useState<string | null>(null);
  const [users, setUsers] = useState<{id: string, username: string, avatar: string, color?: string}[]>([]);
  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  const [roles, setRoles] = useState<{id: string, name: string, color: string}[]>([]);
  const [logs, setLogs] = useState<{id: string, channelName: string, username: string, action: string, content: string, timestamp: number}[]>([]);
  const [selectedUserId, setSelectedUserId] = useState('');
  const [logChannelFilter, setLogChannelFilter] = useState('');
  const [logUserFilter, setLogUserFilter] = useState('');
  const [botStatus, setBotStatus] = useState<{status: string, ping: number, uptime: number} | null>(null);
  const [refreshLogsTrigger, setRefreshLogsTrigger] = useState(0);
  
  const [modmailThreads, setModmailThreads] = useState<{id: string, userId: string, username: string, avatar: string}[]>([]);
  const [selectedThread, setSelectedThread] = useState<string | null>(null);
  const [threadMessages, setThreadMessages] = useState<{id: string, content: string, authorId: string, authorName: string, authorAvatar: string, timestamp: number, isBot: boolean, attachments: {name: string, url: string}[]}[]>([]);
  const [replyContent, setReplyContent] = useState('');

  const [modalConfig, setModalConfig] = useState<{
    isOpen: boolean;
    type: 'user_action' | 'clear_messages' | 'alert';
    action?: string;
    userId?: string;
    username?: string;
    message?: string;
  }>({ isOpen: false, type: 'alert' });

  const [reason, setReason] = useState('');
  const [duration, setDuration] = useState(10);
  const [durationUnit, setDurationUnit] = useState<'minutes' | 'hours' | 'days'>('minutes');
  const [clearAmount, setClearAmount] = useState(10);
  const [selectedChannel, setSelectedChannel] = useState('');
  const [slowmodeRate, setSlowmodeRate] = useState(0);
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedUserForRole, setSelectedUserForRole] = useState('');
  const [customHexColor, setCustomHexColor] = useState('');
  const [customColorName, setCustomColorName] = useState('');
  
  const [selectedUserForRep, setSelectedUserForRep] = useState('');
  const [userRepValue, setUserRepValue] = useState<number>(0);
  const [repInput, setRepInput] = useState<string>('');

  const [serverRoles, setServerRoles] = useState<{id: string, name: string, color: string, position: number, members: number, managed: boolean}[]>([]);
  const [editingRole, setEditingRole] = useState<string | null>(null);
  const [editRoleName, setEditRoleName] = useState('');
  const [editRoleColor, setEditRoleColor] = useState('');
  const [isCreatingRole, setIsCreatingRole] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleColor, setNewRoleColor] = useState('#99aab5');

  const fetchServerRoles = useCallback(() => {
    if (!selectedServer) return;
    fetch(`/api/servers/${selectedServer}/roles`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setServerRoles(data);
        } else {
          console.error('Failed to fetch roles:', data);
          setServerRoles([]);
        }
      })
      .catch(err => {
        console.error('Failed to fetch roles:', err);
        setServerRoles([]);
      });
  }, [selectedServer]);

  useEffect(() => {
    if (selectedServer) {
      fetchServerRoles();
    }
  }, [selectedServer, fetchServerRoles]);

  useEffect(() => {
    if (selectedServer && selectedUserForRep) {
      fetch(`/api/servers/${selectedServer}/members/${selectedUserForRep}/rep`)
        .then(res => res.json())
        .then(data => {
          setUserRepValue(data.rep || 0);
          setRepInput(data.rep?.toString() || '0');
        })
        .catch(err => console.error('Failed to fetch rep:', err));
    }
  }, [selectedServer, selectedUserForRep]);

  const submitReputation = async () => {
    if (!selectedServer || !selectedUserForRep) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/members/${selectedUserForRep}/rep`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rep: Number(repInput) }),
      });
      if (!res.ok) throw new Error('Failed to set reputation');
      setUserRepValue(Number(repInput));
      setModalConfig({ isOpen: true, type: 'alert', message: `Successfully set reputation to ${repInput}.` });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to set reputation.' });
    }
  };

  const deleteRole = async (roleId: string) => {
    if (!selectedServer) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/roles/${roleId}`, {
        method: 'DELETE',
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || 'Failed to delete role');
      }
      setModalConfig({ isOpen: true, type: 'alert', message: 'Role deleted successfully.' });
      fetchServerRoles();
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: err instanceof Error ? err.message : 'Failed to delete role.' });
    }
  };

  const createRole = async () => {
    if (!selectedServer || !newRoleName) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/roles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newRoleName, color: newRoleColor }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || 'Failed to create role');
      }
      setIsCreatingRole(false);
      setNewRoleName('');
      setNewRoleColor('#99aab5');
      setModalConfig({ isOpen: true, type: 'alert', message: 'Role created successfully.' });
      fetchServerRoles();
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: err instanceof Error ? err.message : 'Failed to create role.' });
    }
  };

  const saveRoleEdit = async (roleId: string) => {
    if (!selectedServer) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/roles/${roleId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editRoleName, color: editRoleColor }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || 'Failed to edit role');
      }
      setEditingRole(null);
      setModalConfig({ isOpen: true, type: 'alert', message: 'Role updated successfully.' });
      fetchServerRoles();
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: err instanceof Error ? err.message : 'Failed to edit role.' });
    }
  };

  useEffect(() => {
    const fetchServers = () => {
      fetch('/api/servers')
        .then(res => res.json())
        .then(data => {
          if (data.servers && Array.isArray(data.servers)) {
            setServers(data.servers);
          } else if (Array.isArray(data)) {
            setServers(data);
          } else {
            console.error('Failed to fetch servers:', data);
          }
        })
        .catch(err => console.error('Failed to fetch servers:', err));
    };

    const fetchStatus = () => {
      fetch('/api/status')
        .then(res => res.json())
        .then(data => setBotStatus(data))
        .catch(err => console.error('Failed to fetch status:', err));
    };

    fetchServers();
    fetchStatus();
    const interval = setInterval(() => {
      fetchServers();
      fetchStatus();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedServer) {
      const fetchUsers = () => {
        fetch(`/api/servers/${selectedServer}/users`)
          .then(res => res.json())
          .then(data => {
            if (Array.isArray(data)) {
              setUsers(data);
            } else {
              console.error('Failed to fetch users:', data);
            }
          })
          .catch(err => console.error('Failed to fetch users:', err));
      };

      const fetchLogs = () => {
        fetch(`/api/servers/${selectedServer}/logs`)
          .then(res => res.json())
          .then(data => {
            if (Array.isArray(data)) setLogs(data);
          })
          .catch(err => console.error('Failed to fetch logs:', err));
      };

      const fetchModmailThreads = () => {
        fetch(`/api/servers/${selectedServer}/modmail`)
          .then(res => res.json())
          .then(data => {
            if (Array.isArray(data)) setModmailThreads(data);
          })
          .catch(err => console.error('Failed to fetch modmail threads:', err));
      };

      fetchUsers();
      fetchLogs();
      fetchModmailThreads();

      fetch(`/api/servers/${selectedServer}/channels`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) {
            setChannels(data);
            if (data.length > 0) setSelectedChannel(data[0].id);
          }
        })
        .catch(err => console.error('Failed to fetch channels:', err));

      fetch(`/api/servers/${selectedServer}/roles`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) setRoles(data);
        })
        .catch(err => console.error('Failed to fetch roles:', err));

      const logInterval = setInterval(fetchLogs, 3000);
      const userInterval = setInterval(fetchUsers, 10000);
      const modmailInterval = setInterval(fetchModmailThreads, 5000);

      // Use refreshLogsTrigger to satisfy the linter while keeping it as a dependency to trigger re-runs
      refreshLogsTrigger;

      return () => {
        clearInterval(logInterval);
        clearInterval(userInterval);
        clearInterval(modmailInterval);
      };
    }
  }, [selectedServer, refreshLogsTrigger]);

  useEffect(() => {
    if (selectedServer && selectedThread) {
      const fetchMessages = () => {
        fetch(`/api/servers/${selectedServer}/modmail/${selectedThread}`)
          .then(res => res.json())
          .then(data => {
            if (Array.isArray(data)) setThreadMessages(data);
          })
          .catch(err => console.error('Failed to fetch modmail messages:', err));
      };

      fetchMessages();
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
    setThreadMessages([]);
  }, [selectedServer, selectedThread]);

  const submitModmailReply = async () => {
    if (!selectedServer || !selectedThread || !replyContent.trim()) return;
    try {
      await fetch(`/api/servers/${selectedServer}/modmail/${selectedThread}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: replyContent }),
      });
      setReplyContent('');
      // Optimistically fetch messages
      fetch(`/api/servers/${selectedServer}/modmail/${selectedThread}`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) setThreadMessages(data);
        });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to send reply.' });
    }
  };

  const closeModmailThread = async (threadId: string) => {
    if (!selectedServer) return;
    try {
      await fetch(`/api/servers/${selectedServer}/modmail/${threadId}/close`, {
        method: 'POST'
      });
      if (selectedThread === threadId) setSelectedThread(null);
      setModmailThreads(prev => prev.filter(t => t.id !== threadId));
      setModalConfig({ isOpen: true, type: 'alert', message: 'Successfully closed modmail thread.' });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to close thread.' });
    }
  };

  const openModal = (action: string, user: {id: string, username: string}) => {
    setReason('');
    setDuration(10);
    setModalConfig({
      isOpen: true,
      type: 'user_action',
      action,
      userId: user.id,
      username: user.username
    });
  };

  const submitUserAction = async () => {
    if (!modalConfig.userId || !modalConfig.action) return;
    try {
      let finalDuration = duration;
      if (modalConfig.action === 'timeout') {
        if (durationUnit === 'hours') finalDuration = duration * 60;
        if (durationUnit === 'days') finalDuration = duration * 24 * 60;
      }

      await fetch(`/api/guilds/${selectedServer}/members/${modalConfig.userId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: modalConfig.action, value: finalDuration, reason }),
      });
      setModalConfig({ isOpen: true, type: 'alert', message: `Successfully performed ${modalConfig.action} on ${modalConfig.username}` });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to perform action.' });
    }
  };

  const submitClearMessages = async () => {
    if (!selectedChannel) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/channels/${selectedChannel}/clear`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: clearAmount }),
      });
      if (!res.ok) throw new Error('Failed to clear messages');
      setModalConfig({ isOpen: true, type: 'alert', message: `Successfully cleared ${clearAmount} messages.` });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to clear messages.' });
    }
  };

  const submitSlowmode = async () => {
    if (!selectedChannel) return;
    try {
      await fetch(`/api/servers/${selectedServer}/channels/${selectedChannel}/slowmode`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rateLimitPerUser: slowmodeRate }),
      });
      setModalConfig({ isOpen: true, type: 'alert', message: `Successfully set slowmode to ${slowmodeRate}s.` });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to set slowmode.' });
    }
  };

  const submitRole = async (action: 'add' | 'remove') => {
    if (!selectedUserForRole || !selectedRole) return;
    try {
      await fetch(`/api/servers/${selectedServer}/members/${selectedUserForRole}/roles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roleId: selectedRole, action }),
      });
      setModalConfig({ isOpen: true, type: 'alert', message: `Successfully ${action === 'add' ? 'added' : 'removed'} role.` });
    } catch (err) {
      setModalConfig({ isOpen: true, type: 'alert', message: 'Failed to modify role.' });
    }
  };

  const submitColor = async () => {
    if (!selectedUserForRole || !customHexColor) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/members/${selectedUserForRole}/color`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hexColor: customHexColor, name: customColorName }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to set color');
      
      const formattedColor = customHexColor.startsWith('#') ? customHexColor : `#${customHexColor}`;
      setUsers(prev => prev.map(u => u.id === selectedUserForRole ? { ...u, color: formattedColor } : u));
      
      setModalConfig({ isOpen: true, type: 'alert', message: `Successfully set custom color to ${customHexColor}.` });
      setCustomHexColor('');
      setCustomColorName('');
    } catch (err: unknown) {
      setModalConfig({ isOpen: true, type: 'alert', message: err instanceof Error ? err.message : 'Failed to set custom color.' });
    }
  };

  const removeColor = async () => {
    if (!selectedUserForRole) return;
    try {
      const res = await fetch(`/api/servers/${selectedServer}/members/${selectedUserForRole}/color`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to remove color');
      
      setUsers(prev => prev.map(u => u.id === selectedUserForRole ? { ...u, color: '#ffffff' } : u));
      
      setModalConfig({ isOpen: true, type: 'alert', message: "Successfully removed custom color." });
      setCustomHexColor('');
    } catch (err: unknown) {
      setModalConfig({ isOpen: true, type: 'alert', message: err instanceof Error ? err.message : 'Failed to remove custom color.' });
    }
  };

  const filteredUsers = selectedUserId ? users.filter(u => u.id === selectedUserId) : [];

  const filteredLogs = logs.filter(log => {
    const matchesChannel = logChannelFilter ? log.channelId === logChannelFilter : true;
    const matchesUser = logUserFilter ? log.userId === logUserFilter : true;
    return matchesChannel && matchesUser;
  });

  const getUserWarnings = (userId: string) => {
    return logs.filter(log => log.userId === userId && log.action === 'WARN').length;
  };

  const formatUptime = (ms: number) => {
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12 relative">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-white">TIW Dashboard</h1>
        {botStatus && (
          <div className="flex items-center gap-4 bg-[#141621] border border-slate-800/50 rounded-xl px-4 py-2">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${botStatus.status === 'Online' ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-sm font-medium text-slate-300">{botStatus.status}</span>
            </div>
            <div className="w-px h-4 bg-slate-800" />
            <div className="flex items-center gap-2 text-sm text-slate-300">
              <Zap size={14} className="text-yellow-400" />
              {botStatus.ping}ms
            </div>
            <div className="w-px h-4 bg-slate-800" />
            <div className="flex items-center gap-2 text-sm text-slate-300">
              <Clock size={14} className="text-blue-400" />
              {formatUptime(botStatus.uptime)}
            </div>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden h-fit">
          <div className="p-6 border-b border-slate-800/50">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Server size={20} className="text-blue-400" />
              Servers
            </h2>
          </div>
          <div className="grid grid-cols-1 gap-2 p-4">
            {servers.map(server => (
              <button type="button" 
                key={server.id} 
                onClick={() => setSelectedServer(server.id)}
                className={`w-full p-4 flex items-center justify-between rounded-xl border transition-all ${selectedServer === server.id ? 'bg-blue-600/10 border-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.1)]' : 'bg-slate-800/20 border-slate-800/50 hover:bg-slate-800/40 hover:border-slate-700'}`}
              >
                <span className="text-sm text-slate-200 font-medium">{server.name}</span>
                <span className="text-xs text-slate-500 bg-slate-900/50 px-2 py-1 rounded-md">{server.memberCount} members</span>
              </button>
            ))}
          </div>
        </section>

        <div className="lg:col-span-2 space-y-8">
          {!selectedServer ? (
            <div className="bg-[#141621] border border-slate-800/50 rounded-2xl p-12 flex flex-col items-center justify-center text-center h-full min-h-[400px]">
              <Server size={48} className="text-slate-600 mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Select a Server</h3>
              <p className="text-slate-400 max-w-md">Choose a server from the list to view its dashboard, manage users, and configure settings.</p>
            </div>
          ) : (
            <>
              <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-6 border-b border-slate-800/50 bg-slate-800/20">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Shield size={20} className="text-purple-400" />
                    Server Commands
                  </h2>
                </div>
                <div className="p-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
                  <div className="bg-slate-800/20 border border-slate-700/50 rounded-xl p-5 hover:border-slate-600/50 transition-colors">
                    <h3 className="text-base font-semibold text-white mb-1 flex items-center gap-2"><Trash2 size={16} className="text-red-400"/> Clear Messages</h3>
                    <p className="text-xs text-slate-400 mb-4">Bulk delete messages from a specific channel.</p>
                    <div className="flex flex-col gap-3">
                      <div>
                        <label htmlFor="clear-channel" className="block text-xs font-medium text-slate-400 mb-1">Channel</label>
                        <select id="clear-channel" value={selectedChannel} onChange={e => setSelectedChannel(e.target.value)} className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-slate-500 focus:outline-none">
                          {channels.map(c => <option key={c.id} value={c.id}>#{c.name}</option>)}
                        </select>
                      </div>
                      <div className="flex gap-3 items-end">
                        <div className="flex-1">
                          <label htmlFor="clear-amount" className="block text-xs font-medium text-slate-400 mb-1">Amount (1-100)</label>
                          <input id="clear-amount" type="number" min="1" max="100" value={clearAmount} onChange={e => setClearAmount(Number(e.target.value))} className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-slate-500 focus:outline-none" />
                        </div>
                        <button type="button" onClick={submitClearMessages} className="px-4 py-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 rounded-lg text-sm font-medium transition-colors whitespace-nowrap">
                          Clear
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/20 border border-slate-700/50 rounded-xl p-5 hover:border-slate-600/50 transition-colors">
                    <h3 className="text-base font-semibold text-white mb-1 flex items-center gap-2"><Clock size={16} className="text-blue-400"/> Slowmode</h3>
                    <p className="text-xs text-slate-400 mb-4">Set the rate limit per user for a channel.</p>
                    <div className="flex flex-col gap-3">
                      <div>
                        <label htmlFor="slowmode-channel" className="block text-xs font-medium text-slate-400 mb-1">Channel</label>
                        <select id="slowmode-channel" value={selectedChannel} onChange={e => setSelectedChannel(e.target.value)} className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-slate-500 focus:outline-none">
                          {channels.map(c => <option key={c.id} value={c.id}>#{c.name}</option>)}
                        </select>
                      </div>
                      <div className="flex gap-3 items-end">
                        <div className="flex-1">
                          <label htmlFor="slowmode-seconds" className="block text-xs font-medium text-slate-400 mb-1">Seconds (0-21600)</label>
                          <input id="slowmode-seconds" type="number" min="0" max="21600" value={slowmodeRate} onChange={e => setSlowmodeRate(Number(e.target.value))} className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-slate-500 focus:outline-none" />
                        </div>
                        <button type="button" onClick={submitSlowmode} className="px-4 py-2 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/20 rounded-lg text-sm font-medium transition-colors whitespace-nowrap">
                          Set
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/20 border border-slate-700/50 rounded-xl p-6 xl:col-span-2 hover:border-slate-600/50 transition-colors flex flex-col gap-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2"><UserPlus size={18} className="text-green-400"/> Manage Roles</h3>
                        <p className="text-sm text-slate-400">Search for a user to assign or remove roles.</p>
                      </div>
                      <div className="w-full sm:w-72">
                        <UserSelect 
                          serverId={selectedServer}
                          value={selectedUserForRole} 
                          onChange={setSelectedUserForRole} 
                          placeholder="Search to select a user..." 
                        />
                      </div>
                    </div>

                    {selectedUserForRole ? (
                      <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-5 flex flex-col gap-5">
                        <div className="flex items-center gap-4 pb-5 border-b border-slate-700/50">
                          <div className="flex flex-col">
                            <span className="text-lg font-medium" style={{ color: users.find(u => u.id === selectedUserForRole)?.color || '#e2e8f0' }}>
                              {users.find(u => u.id === selectedUserForRole)?.username || 'Selected User'}
                            </span>
                            <span className="text-xs text-slate-500">ID: {selectedUserForRole}</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-col sm:flex-row gap-4 items-end">
                          <div className="flex-1 w-full">
                            <label htmlFor="role-select" className="block text-sm font-medium text-slate-400 mb-2">Select Role</label>
                            <select id="role-select" value={selectedRole} onChange={e => setSelectedRole(e.target.value)} className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:border-slate-500 focus:outline-none">
                              <option value="">Choose a role...</option>
                              {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                            </select>
                          </div>
                          <div className="flex gap-3 w-full sm:w-auto">
                            <button type="button" onClick={() => submitRole('add')} className="flex-1 sm:flex-none px-6 py-2.5 bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20 rounded-lg text-sm font-medium transition-colors">
                              Add Role
                            </button>
                            <button type="button" onClick={() => submitRole('remove')} className="flex-1 sm:flex-none px-6 py-2.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 rounded-lg text-sm font-medium transition-colors">
                              Remove Role
                            </button>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-4 items-end pt-4 border-t border-slate-700/50">
                          <div className="flex-1 w-full">
                            <label htmlFor="custom-color" className="block text-sm font-medium text-slate-400 mb-2">Custom Nickname Color (Hex)</label>
                            <div className="flex gap-2 items-center">
                              <div className="w-10 h-10 rounded-lg border border-slate-700 shrink-0" style={{ backgroundColor: customHexColor || 'transparent' }} />
                              <input 
                                id="custom-color" 
                                type="text" 
                                placeholder="#FF0000" 
                                value={customHexColor} 
                                onChange={e => setCustomHexColor(e.target.value)} 
                                className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:border-slate-500 focus:outline-none" 
                              />
                            </div>
                          </div>
                          <div className="flex-1 w-full">
                            <label htmlFor="custom-color-name" className="block text-sm font-medium text-slate-400 mb-2">Color Role Name (Optional)</label>
                            <input 
                              id="custom-color-name" 
                              type="text" 
                              placeholder="e.g. My Cool Color" 
                              value={customColorName} 
                              onChange={e => setCustomColorName(e.target.value)} 
                              className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:border-slate-500 focus:outline-none" 
                            />
                          </div>
                          <div className="flex gap-3 w-full sm:w-auto">
                            <button type="button" onClick={submitColor} className="flex-1 sm:flex-none px-6 py-2.5 bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 border border-purple-500/20 rounded-lg text-sm font-medium transition-colors">
                              Set Color
                            </button>
                            <button type="button" onClick={removeColor} className="flex-1 sm:flex-none px-6 py-2.5 bg-slate-500/10 text-slate-400 hover:bg-slate-500/20 border border-slate-500/20 rounded-lg text-sm font-medium transition-colors">
                              Remove Color
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-slate-900/30 border border-slate-800 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center">
                        <UserPlus size={32} className="text-slate-600 mb-3" />
                        <p className="text-slate-400 text-sm">Search and select a user above to manage their roles.</p>
                      </div>
                    )}
                  </div>
                </div>
              </section>

              <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/20">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Users size={20} className="text-green-400" />
                    User Management
                  </h2>
                  <div className="w-full sm:w-64">
                    <UserSelect 
                      serverId={selectedServer}
                      value={selectedUserId} 
                      onChange={setSelectedUserId} 
                      placeholder="Search to select a user..." 
                    />
                  </div>
                </div>
                <div className="divide-y divide-slate-800/50 max-h-[400px] overflow-y-auto">
                  {!selectedUserId ? (
                    <div className="p-12 flex flex-col items-center justify-center text-center">
                      <Search size={32} className="text-slate-600 mb-3" />
                      <p className="text-slate-400 text-sm">
                        Search and select a user to view their details and manage actions.
                      </p>
                    </div>
                  ) : (
                    <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-800/20 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="flex flex-col">
                          <span className="text-base font-medium" style={{ color: users.find(u => u.id === selectedUserId)?.color || '#e2e8f0' }}>
                            {users.find(u => u.id === selectedUserId)?.username || 'Selected User'}
                          </span>
                          <span className="text-xs text-slate-500">ID: {selectedUserId}</span>
                          <span className="text-xs font-medium text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded-full w-fit mt-1">
                            {getUserWarnings(selectedUserId)} Warnings
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button type="button" onClick={() => openModal('warn', {id: selectedUserId, username: 'User'})} className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-yellow-400 bg-yellow-400/10 hover:bg-yellow-400/20 border border-yellow-400/20 rounded-lg transition-colors"><AlertTriangle size={14} /> Warn</button>
                        <button type="button" onClick={() => openModal('timeout', {id: selectedUserId, username: 'User'})} className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-blue-400 bg-blue-400/10 hover:bg-blue-400/20 border border-blue-400/20 rounded-lg transition-colors"><Clock size={14} /> Timeout</button>
                        <button type="button" onClick={() => openModal('kick', {id: selectedUserId, username: 'User'})} className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-orange-400 bg-orange-400/10 hover:bg-orange-400/20 border border-orange-400/20 rounded-lg transition-colors"><UserMinus size={14} /> Kick</button>
                        <button type="button" onClick={() => openModal('ban', {id: selectedUserId, username: 'User'})} className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-red-400 bg-red-400/10 hover:bg-red-400/20 border border-red-400/20 rounded-lg transition-colors"><Ban size={14} /> Ban</button>
                      </div>
                    </div>
                  )}
                </div>
              </section>

              <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/20">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Award size={20} className="text-yellow-400" />
                    Reputation Management
                  </h2>
                  <div className="w-full sm:w-64">
                    <UserSelect 
                      serverId={selectedServer}
                      value={selectedUserForRep} 
                      onChange={setSelectedUserForRep} 
                      placeholder="Search to select a user..." 
                    />
                  </div>
                </div>
                <div className="p-6">
                  {selectedUserForRep ? (
                    <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-5 flex flex-col sm:flex-row items-center gap-6">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="flex flex-col">
                          <span className="text-xl text-slate-200 font-bold">Selected User</span>
                          <span className="text-xs text-slate-500">ID: {selectedUserForRep}</span>
                          <span className="text-sm text-slate-400 mt-1">Current Rep: <span className="text-yellow-400 font-bold">{userRepValue}</span></span>
                        </div>
                      </div>
                      <div className="flex items-end gap-3 w-full sm:w-auto">
                        <div className="flex-1 sm:w-32">
                          <label htmlFor="rep-amount" className="block text-xs font-medium text-slate-400 mb-1">Set Reputation</label>
                          <input 
                            id="rep-amount" 
                            type="number" 
                            value={repInput} 
                            onChange={e => setRepInput(e.target.value)} 
                            className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-yellow-500 focus:outline-none" 
                          />
                        </div>
                        <button 
                          type="button" 
                          onClick={submitReputation} 
                          className="px-6 py-2 bg-yellow-500/10 text-yellow-400 hover:bg-yellow-500/20 border border-yellow-500/20 rounded-lg text-sm font-medium transition-colors"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-slate-900/30 border border-slate-800 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center">
                      <Award size={32} className="text-slate-600 mb-3" />
                      <p className="text-slate-400 text-sm">Search and select a user above to manage their reputation.</p>
                    </div>
                  )}
                </div>
              </section>

              <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/20">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Shield size={20} className="text-purple-400" />
                    Role Management
                  </h2>
                  <button
                    type="button"
                    onClick={() => setIsCreatingRole(true)}
                    className="px-4 py-2 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/20 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                  >
                    <Plus size={16} />
                    Create New Role
                  </button>
                </div>
                {isCreatingRole && (
                  <div className="p-4 border-b border-slate-800/50 bg-slate-800/30 flex flex-col sm:flex-row gap-4">
                    <div className="flex-1 flex flex-col sm:flex-row gap-3">
                      <input 
                        type="text" 
                        value={newRoleName} 
                        onChange={e => setNewRoleName(e.target.value)} 
                        placeholder="New Role Name"
                        className="flex-1 bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-blue-500 focus:outline-none" 
                      />
                      <div className="flex items-center gap-2">
                        <input 
                          type="color" 
                          value={newRoleColor} 
                          onChange={e => setNewRoleColor(e.target.value)} 
                          className="w-8 h-8 rounded cursor-pointer bg-transparent border-0 p-0" 
                        />
                        <span className="text-xs text-slate-400 font-mono">{newRoleColor}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button type="button" onClick={createRole} className="px-3 py-1.5 bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20 rounded-lg text-sm font-medium transition-colors">Create</button>
                      <button type="button" onClick={() => setIsCreatingRole(false)} className="px-3 py-1.5 bg-slate-700/50 text-slate-300 hover:bg-slate-700 border border-slate-600 rounded-lg text-sm font-medium transition-colors">Cancel</button>
                    </div>
                  </div>
                )}
                <div className="divide-y divide-slate-800/50 max-h-[400px] overflow-y-auto">
                  {serverRoles.length === 0 ? (
                    <div className="p-12 flex flex-col items-center justify-center text-center">
                      <Shield size={32} className="text-slate-600 mb-3" />
                      <p className="text-slate-400 text-sm">No roles found or loading...</p>
                    </div>
                  ) : (
                    serverRoles.map(role => (
                      <div key={role.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-800/20 transition-colors">
                        {editingRole === role.id ? (
                          <div className="flex-1 flex flex-col sm:flex-row gap-3">
                            <input 
                              type="text" 
                              value={editRoleName} 
                              onChange={e => setEditRoleName(e.target.value)} 
                              className="flex-1 bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-purple-500 focus:outline-none" 
                              placeholder="Role Name"
                            />
                            <div className="flex items-center gap-2">
                              <input 
                                type="color" 
                                value={editRoleColor} 
                                onChange={e => setEditRoleColor(e.target.value)} 
                                className="w-8 h-8 rounded cursor-pointer bg-transparent border-0 p-0" 
                              />
                              <input 
                                type="text" 
                                value={editRoleColor} 
                                onChange={e => setEditRoleColor(e.target.value)} 
                                className="w-24 bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:border-purple-500 focus:outline-none" 
                                placeholder="#FFFFFF"
                              />
                            </div>
                            <div className="flex gap-2">
                              <button type="button" onClick={() => saveRoleEdit(role.id)} className="px-3 py-1.5 bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20 rounded-lg text-sm font-medium transition-colors">Save</button>
                              <button type="button" onClick={() => setEditingRole(null)} className="px-3 py-1.5 bg-slate-700/50 text-slate-300 hover:bg-slate-700 border border-slate-600 rounded-lg text-sm font-medium transition-colors">Cancel</button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="flex items-center gap-4">
                              <div className="w-4 h-4 rounded-full" style={{ backgroundColor: role.color !== '#000000' ? role.color : '#99aab5' }} />
                              <div className="flex flex-col">
                                <span className="text-base text-slate-200 font-medium">{role.name}</span>
                                <span className="text-xs text-slate-500">{role.members} members • Position: {role.position}</span>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {!role.managed && (
                                <>
                                  <button 
                                    type="button" 
                                    onClick={() => {
                                      setEditingRole(role.id);
                                      setEditRoleName(role.name);
                                      setEditRoleColor(role.color !== '#000000' ? role.color : '#99aab5');
                                    }} 
                                    className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-blue-400 bg-blue-400/10 hover:bg-blue-400/20 border border-blue-400/20 rounded-lg transition-colors"
                                  >
                                    Edit
                                  </button>
                                  <button 
                                    type="button" 
                                    onClick={() => deleteRole(role.id)} 
                                    className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-red-400 bg-red-400/10 hover:bg-red-400/20 border border-red-400/20 rounded-lg transition-colors"
                                  >
                                    <Trash2 size={14} /> Delete
                                  </button>
                                </>
                              )}
                              {role.managed && (
                                <span className="px-3 py-1.5 text-xs font-medium text-slate-500 bg-slate-800/50 rounded-lg border border-slate-700/50">Managed Integration</span>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </section>

              <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/20">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Mail size={20} className="text-indigo-400" />
                    ModMail
                  </h2>
                </div>
                <div className="flex flex-col md:flex-row h-[500px]">
                  <div className="w-full md:w-1/3 border-r border-slate-800/50 bg-slate-900/30 overflow-y-auto">
                    {modmailThreads.length === 0 ? (
                      <div className="p-8 text-center text-slate-500 text-sm flex flex-col items-center justify-center h-full">
                        <Mail size={32} className="text-slate-600 mb-3 opacity-50" />
                        No active ModMail threads.
                      </div>
                    ) : (
                      <div className="divide-y divide-slate-800/50">
                        {modmailThreads.map(thread => (
                          <button
                            key={thread.id}
                            type="button"
                            onClick={() => setSelectedThread(thread.id)}
                            className={`w-full p-4 flex items-center gap-3 text-left transition-colors ${selectedThread === thread.id ? 'bg-indigo-500/10 border-l-2 border-indigo-500' : 'hover:bg-slate-800/30 border-l-2 border-transparent'}`}
                          >
                            <img src={thread.avatar} alt={thread.username} className="w-10 h-10 rounded-full border border-slate-700" />
                            <div className="flex flex-col overflow-hidden">
                              <span className="text-sm font-medium text-slate-200 truncate">{thread.username}</span>
                              <span className="text-xs text-slate-500 truncate">ID: {thread.userId}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="w-full md:w-2/3 flex flex-col bg-[#141621]">
                    {!selectedThread ? (
                      <div className="p-12 text-center text-slate-500 text-sm flex flex-col items-center justify-center h-full">
                        <Mail size={48} className="text-slate-700 mb-4 opacity-50" />
                        Select a thread from the left to view messages and reply.
                      </div>
                    ) : (
                      <>
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 flex flex-col-reverse">
                          {threadMessages.map(msg => (
                            <div key={msg.id} className={`flex flex-col max-w-[80%] ${msg.isBot ? 'self-end items-end' : 'self-start items-start'}`}>
                              <div className="flex items-center gap-2 mb-1">
                                {!msg.isBot && <img src={msg.authorAvatar} alt={msg.authorName} className="w-5 h-5 rounded-full" />}
                                <span className="text-xs font-medium text-slate-400">{msg.isBot ? 'Staff Reply' : msg.authorName}</span>
                                <span className="text-[10px] text-slate-600">{new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                              </div>
                              <div className={`p-3 rounded-2xl text-sm ${msg.isBot ? 'bg-indigo-600 text-white rounded-tr-sm' : 'bg-slate-800 text-slate-200 rounded-tl-sm'}`}>
                                {msg.content}
                                {msg.attachments && msg.attachments.length > 0 && (
                                  <div className="mt-2 space-y-1">
                                    {msg.attachments.map((att) => (
                                      <a key={att.url} href={att.url} target="_blank" rel="noreferrer" className="block text-xs underline text-blue-300 hover:text-blue-200">
                                        {att.name}
                                      </a>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="p-4 border-t border-slate-800/50 bg-slate-900/50">
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={replyContent}
                              onChange={e => setReplyContent(e.target.value)}
                              onKeyDown={e => e.key === 'Enter' && submitModmailReply()}
                              placeholder="Type a reply..."
                              className="flex-1 bg-[#0f111a] border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                            />
                            <button
                              type="button"
                              onClick={submitModmailReply}
                              disabled={!replyContent.trim()}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg text-sm font-medium transition-colors"
                            >
                              Send
                            </button>
                            <button
                              type="button"
                              onClick={() => closeModmailThread(selectedThread)}
                              className="px-4 py-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 rounded-lg text-sm font-medium transition-colors"
                            >
                              Close
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </section>

              <section className="bg-[#141621] border border-slate-800/50 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/20">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Activity size={20} className="text-yellow-400" />
                    Live Message Logs
                  </h2>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="flex items-center gap-2 px-3 py-2 bg-slate-900/50 border border-slate-700 rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-xs text-slate-300 font-medium">Live Updates</span>
                    </div>
                    <select 
                      value={logChannelFilter} 
                      onChange={e => setLogChannelFilter(e.target.value)} 
                      className="bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-slate-500"
                    >
                      <option value="">All Channels</option>
                      {channels.map(c => <option key={c.id} value={c.id}>#{c.name}</option>)}
                    </select>
                    <div className="w-full sm:w-48">
                      <UserSelect 
                        serverId={selectedServer}
                        value={logUserFilter} 
                        onChange={setLogUserFilter} 
                        placeholder="Filter by user..." 
                      />
                    </div>
                  </div>
                </div>
                <div className="divide-y divide-slate-800/50 max-h-[600px] overflow-y-auto bg-[#0f111a]/50">
                  {filteredLogs.length === 0 ? (
                    <div className="p-12 text-center text-slate-500 text-sm flex flex-col items-center justify-center">
                      <Activity size={32} className="text-slate-600 mb-3 opacity-50" />
                      Waiting for new messages...
                    </div>
                  ) : (
                    filteredLogs.map(log => (
                      <div key={log.id} className="p-4 hover:bg-slate-800/30 transition-colors flex flex-col gap-2">
                        <div className="flex items-center gap-3">
                          <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-1 rounded-md ${
                            log.action === 'CREATE' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                            log.action === 'UPDATE' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' :
                            log.action === 'WARN' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' :
                            'bg-red-500/10 text-red-400 border border-red-500/20'
                          }`}>{log.action}</span>
                          <span className="text-sm font-semibold text-slate-200">{log.username}</span>
                          <span className="text-xs text-slate-500 flex items-center gap-1">
                            in <span className="text-slate-300 font-medium">#{log.channelName}</span>
                          </span>
                          <span className="text-xs text-slate-500 ml-auto bg-slate-800/80 px-2 py-1 rounded-md border border-slate-700/50">
                            {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}
                          </span>
                        </div>
                        <div className="text-sm text-slate-300 whitespace-pre-wrap break-words pl-3 border-l-2 border-slate-700 ml-1 font-mono bg-slate-900/30 p-2 rounded-r-lg">
                          {log.content}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </section>
            </>
          )}
        </div>
      </div>

      {modalConfig.isOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-[#1a1d27] border border-slate-700 rounded-xl p-6 w-full max-w-md shadow-2xl">
            {modalConfig.type === 'user_action' && (
              <>
                <h3 className="text-xl font-bold text-white mb-4 capitalize">{modalConfig.action} User</h3>
                <p className="text-slate-300 mb-4">Target: <span className="font-semibold text-white">{modalConfig.username}</span></p>

                {modalConfig.action === 'timeout' && (
                  <div className="mb-4">
                    <label htmlFor="action-duration" className="block text-sm text-slate-400 mb-1">Duration</label>
                    <div className="flex gap-2">
                      <input id="action-duration" type="number" value={duration} onChange={e => setDuration(Number(e.target.value))} className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-white" />
                      <select value={durationUnit} onChange={e => setDurationUnit(e.target.value as 'minutes' | 'hours' | 'days')} className="bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-white">
                        <option value="minutes">Minutes</option>
                        <option value="hours">Hours</option>
                        <option value="days">Days</option>
                      </select>
                    </div>
                  </div>
                )}

                <div className="mb-6">
                  <label htmlFor="action-reason" className="block text-sm text-slate-400 mb-1">Reason</label>
                  <input id="action-reason" type="text" value={reason} onChange={e => setReason(e.target.value)} placeholder="Optional reason..." className="w-full bg-[#0f111a] border border-slate-700 rounded-lg p-2 text-white" />
                </div>

                <div className="flex justify-end gap-3">
                  <button type="button" onClick={() => setModalConfig({ isOpen: false, type: 'alert' })} className="px-4 py-2 rounded-lg text-slate-300 hover:bg-slate-800">Cancel</button>
                  <button type="button" onClick={submitUserAction} className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium">Confirm</button>
                </div>
              </>
            )}

            {modalConfig.type === 'alert' && (
              <>
                <h3 className="text-xl font-bold text-white mb-4">Notification</h3>
                <p className="text-slate-300 mb-6">{modalConfig.message}</p>
                <div className="flex justify-end">
                  <button type="button" onClick={() => setModalConfig({ isOpen: false, type: 'alert' })} className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium">Close</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
