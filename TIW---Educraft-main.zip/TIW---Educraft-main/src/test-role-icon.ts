import { Client, GatewayIntentBits } from 'discord.js';
import 'dotenv/config';

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.on('ready', async () => {
    console.log('Ready!');
    const guild = client.guilds.cache.first();
    if (!guild) return console.log('No guild found');
    
    console.log('Guild features:', guild.features);
    
    try {
        const role = await guild.roles.create({
            name: 'Test Role Icon',
            icon: 'https://cdn.discordapp.com/emojis/1489359176923611217.png?size=64'
        });
        console.log('Role created:', role.name, role.icon);
    } catch (e) {
        console.error('Error creating role:', e);
    }
    
    client.destroy();
});

client.login(process.env.DISCORD_TOKEN);
