import { GuildPreferences, QuestionOfTheWeek } from "@/mongo";
import type { DiscordClient } from "@/registry/DiscordClient";
import BaseCommand, {
	type DiscordChatInputCommandInteraction,
} from "@/registry/Structure/BaseCommand";
import {
	ChannelType,
	EmbedBuilder,
	PermissionFlagsBits,
	SlashCommandBuilder,
	type TextChannel,
} from "discord.js";

export default class extends BaseCommand {
	constructor() {
		super(
			new SlashCommandBuilder()
				.setName("qotd")
				.setDescription("Send today's question (for mods)")
				.setDMPermission(false)
				.addStringOption((option) =>
					option
						.setName("question")
						.setDescription(
							"The question to be asked (leave empty for a random question)",
						)
						.setRequired(false),
				)
				.setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
		);
	}

	async execute(
		client: DiscordClient<true>,
		interaction: DiscordChatInputCommandInteraction<"cached">,
	) {
		await interaction.deferReply({ ephemeral: true });

		let question = interaction.options.getString("question", false);
		let qotwDocId = null;

		if (!question) {
			const randomQuestion = await QuestionOfTheWeek.aggregate([
				{
					$match: {
						guildId: interaction.guildId,
					},
				},
				{ $sample: { size: 1 } },
			]);

			if (!randomQuestion.length || !randomQuestion[0]) {
				await interaction.editReply({
					content:
						"No questions found in the database for this guild.",
				});
				return;
			}

			question = randomQuestion[0].question;
			qotwDocId = randomQuestion[0]._id;
		}

		const guildPreferences = await GuildPreferences.findOne({
			guildId: interaction.guildId,
		});

		if (
			!guildPreferences ||
			!guildPreferences.qotwChannelId ||
			!guildPreferences.qotwRoleId
		) {
			await interaction.editReply({
				content:
					"Please configure both the QOTD channel and QOTD role in Guild Preferences.",
			});
			return;
		}

		const channel = interaction.guild.channels.cache.get(
			guildPreferences.qotwChannelId,
		);

		if (
			!channel ||
			!channel.isTextBased() ||
			(channel.type !== ChannelType.GuildText && channel.type !== ChannelType.GuildAnnouncement)
		) {
			await interaction.editReply({
				content:
					"The configured QOTD channel is invalid or does not support threads.",
			});
			return;
		}

		try {
			const role = interaction.guild.roles.cache.get(
				guildPreferences.qotwRoleId,
			);

			const embed = new EmbedBuilder()
				.setTitle("Question of the Day")
				.setDescription(question.length > 4096 ? `${question.slice(0, 4093)}...` : question)
				.setColor(role?.hexColor || "#FFFFFF");

			const message = await (channel as TextChannel).send({
				content: `<@&${guildPreferences.qotwRoleId}>`,
				embeds: [embed],
			});

			const date = new Date().toISOString().split("T")[0];

			const thread = await message.startThread({
				name: `QOTD - (${date})`,
			}).catch((err) => {
				console.error("Failed to create thread:", err);
				return null;
			});

			if (thread) {
				await thread.send("Answer today's question here").catch(console.error);
			}

			if (qotwDocId) {
				await QuestionOfTheWeek.updateOne(
					{ _id: qotwDocId },
					{ asked: true },
				);
			}

			const remaining = await QuestionOfTheWeek.countDocuments({
				guildId: interaction.guildId,
				asked: { $ne: true },
			});

			await interaction.editReply({
				content: `Question sent to ${channel} (Unasked questions remaining: ${remaining})`,
			});
		} catch (error) {
			console.error(error);
			await interaction.editReply({
				content: `An error occurred while sending the question: ${error instanceof Error ? error.message : error}`,
			});
		}
	}
}
