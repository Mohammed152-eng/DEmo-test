import { SlashCommandBuilder } from "discord.js";
import BaseCommand, {
	type DiscordChatInputCommandInteraction,
} from "@/registry/Structure/BaseCommand";
import { Reputation } from "@/mongo";
import { Logger } from "@discordforge/logger";

import { applyUniqueFont } from "@/utils/fontUtils";

export default class SyncProfileCommand extends BaseCommand {
	constructor() {
		super(
			new SlashCommandBuilder()
				.setName("sync-profile")
				.setDescription("Syncs your profile (nickname stars, etc) based on your reputation.")
				.setDMPermission(false),
		);
	}

	async execute(
		client: DiscordClient<true>,
		interaction: DiscordChatInputCommandInteraction<"cached">,
	) {
		await interaction.deferReply({ ephemeral: true });

		try {
			const repDoc = await Reputation.findOne({
				guildId: interaction.guildId,
				userId: interaction.user.id,
			});

			const userRep = repDoc?.rep || 0;
			const currentName = interaction.member.displayName;
			let newName = currentName.replace(/ ⭐| 🌟/g, '');
			let changed = false;

			if (userRep >= 500) {
				newName = `${newName} 🌟`;
				changed = true;
			} else if (userRep >= 100) {
				newName = `${newName} ⭐`;
				changed = true;
			}

			let assignedRole = false;
			const milestones = [
				{ rep: 1000, roleName: "Elite Helper", emoji: "<:elite:1351197724246278170>", iconUrl: "https://cdn.discordapp.com/emojis/1351197724246278170.png?size=64" },
				{ rep: 750, roleName: "Veteran", emoji: "<:veteran:1489359269206822983>", iconUrl: "https://cdn.discordapp.com/emojis/1489359269206822983.png?size=64" },
				{ rep: 500, roleName: "Contributor", emoji: "🌟", iconUrl: null },
				{ rep: 100, roleName: "Rising Star", emoji: "⭐", iconUrl: null },
				{ rep: 50, roleName: "Rookie", emoji: "<:rookie:1489359176923611217>", iconUrl: "https://cdn.discordapp.com/emojis/1489359176923611217.png?size=64" }
			];

			const canSetRoleIcon = interaction.guild.features.includes('ROLE_ICONS');

			// Booster logic
			if (interaction.member.premiumSince) {
				const boosterRoleName = `Booster-${interaction.user.id}`;
				let boosterRole = interaction.guild.roles.cache.find((r) => r.name === boosterRoleName);
				
				const botHighestRole = interaction.guild.members.me?.roles.highest;
				const userColoredRoles = interaction.member.roles.cache.filter(r => r.color !== 0 && (!boosterRole || r.id !== boosterRole.id));
				const highestUserColorRole = userColoredRoles.sort((a, b) => b.position - a.position).first();
				
				let targetPosition = highestUserColorRole ? highestUserColorRole.position + 1 : 1;
				if (botHighestRole && targetPosition >= botHighestRole.position) {
					targetPosition = botHighestRole.position - 1;
				}

				if (!boosterRole) {
					try {
						boosterRole = await interaction.guild.roles.create({
							name: boosterRoleName,
							color: "#FF00FF",
							position: targetPosition > 0 ? targetPosition : 1,
							reason: "Server Booster automatic color",
						});
					} catch (e) {
						Logger.error(`Failed to create booster role: ${e}`);
					}
				} else if (boosterRole.hexColor.toUpperCase() !== "#FF00FF") {
					await boosterRole.setColor("#FF00FF").catch(() => {});
				}

				if (boosterRole && !interaction.member.roles.cache.has(boosterRole.id)) {
					await interaction.member.roles.add(boosterRole).catch(() => {});
					assignedRole = true;
				}

				// Apply unique font to nickname
				const cleanName = newName.replace(/ ⭐| 🌟/g, '');
				const fontName = applyUniqueFont(cleanName);
				
				// Re-append stars if needed
				const starsMatch = newName.match(/ ⭐| 🌟/g);
				newName = starsMatch ? `${fontName}${starsMatch.join('')}` : fontName;
				changed = true;
			}

			for (const milestone of milestones) {
				if (userRep >= milestone.rep) {
					let role = interaction.guild.roles.cache.find(
						(x) => x.name === milestone.roleName,
					);

					const isUnicodeEmoji = milestone.emoji === "⭐" || milestone.emoji === "🌟";
					const iconUrl = milestone.iconUrl;

					const botHighestRole = interaction.guild.members.me?.roles.highest;
					const userColoredRoles = interaction.member.roles.cache.filter(r => r.color !== 0 && (!role || r.id !== role.id));
					const highestUserColorRole = userColoredRoles.sort((a, b) => b.position - a.position).first();
					
					let targetPosition = highestUserColorRole ? highestUserColorRole.position + 1 : 1;
					if (botHighestRole && targetPosition >= botHighestRole.position) {
						targetPosition = botHighestRole.position - 1;
					}

					let targetColor: `#${string}` | undefined = undefined;
					if (milestone.rep === 100) targetColor = "#FF0000";
					else if (milestone.rep === 500) targetColor = "#00FF00";
					else if (milestone.rep === 1000) targetColor = "#00FFFF";

					if (!role) {
						try {
							role = await interaction.guild.roles.create({
								name: milestone.roleName,
								reason: `Reached ${milestone.rep} reputation`,
								unicodeEmoji: (isUnicodeEmoji && canSetRoleIcon) ? milestone.emoji : null,
								icon: (iconUrl && canSetRoleIcon) ? iconUrl : null,
								color: targetColor,
								position: targetPosition > 0 ? targetPosition : 1,
							});
						} catch (e) {
							Logger.error(`Failed to create role ${milestone.roleName}: ${e}`);
						}
					} else {
						try {
							const updates: import("discord.js").RoleEditOptions = {};
							if (canSetRoleIcon) {
								if (isUnicodeEmoji && role.unicodeEmoji !== milestone.emoji) {
									updates.unicodeEmoji = milestone.emoji;
								} else if (iconUrl && !role.icon) {
									updates.icon = iconUrl;
								}
							}
							if (targetColor && role.hexColor.toUpperCase() !== targetColor) {
								updates.color = targetColor;
							}
							
							if (role.position < targetPosition) {
								updates.position = targetPosition > 0 ? targetPosition : 1;
							}
							
							if (Object.keys(updates).length > 0) {
								await role.edit(updates);
							}
						} catch (e) {
							Logger.error(`Failed to update role for ${milestone.roleName}: ${e}`);
						}
					}

					if (role && !interaction.member.roles.cache.has(role.id)) {
						await interaction.member.roles.add(role).catch(() => {});
						assignedRole = true;
						
						// Remove custom color roles so the milestone color shows
						if (targetColor) {
							const customColorRoles = interaction.member.roles.cache.filter(r => 
								(r.members.size === 1 && r.color !== 0 && !r.name.startsWith('Booster-')) || 
								r.name.startsWith('Color-')
							);
							if (customColorRoles.size > 0) {
								await interaction.member.roles.remove(customColorRoles).catch(() => {});
							}
						}
					}
				}
			}

			if ((changed && newName !== currentName) || assignedRole) {
				if (changed && newName !== currentName) {
					await interaction.member.setNickname(newName);
				}
				await interaction.editReply({
					content: "Successfully synced your profile! Your roles and nickname have been updated.",
				});
			} else {
				await interaction.editReply({
					content: "Your profile is already synced or you haven't reached any milestones yet.",
				});
			}
		} catch (error: unknown) {
			Logger.error(`Failed to sync profile: ${error}`);
			if (error instanceof Error && (error as { code?: number }).code === 50013) {
				await interaction.editReply({
					content: "I don't have permission to change your nickname. This usually happens if you are the Server Owner or have a role higher than the bot.",
				});
			} else {
				await interaction.editReply({
					content: "An error occurred while syncing your profile.",
				});
			}
		}
	}
}
