import { Reputation } from "@/mongo";
import type { DiscordClient } from "@/registry/DiscordClient";
import BaseCommand, {
	type DiscordChatInputCommandInteraction,
} from "@/registry/Structure/BaseCommand";
import { SlashCommandBuilder, MessageFlags, PermissionFlagsBits } from "discord.js";

const HEX_REGEX = /^#?([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;

export default class CustomColorCommand extends BaseCommand {
	constructor() {
		super(
			new SlashCommandBuilder()
				.setName("customcolor")
				.setDescription("Set a custom nickname color for a user (Admin only)")
				.addUserOption((option) =>
					option
						.setName("user")
						.setDescription("The user to give the color to")
						.setRequired(true),
				)
				.addStringOption((option) =>
					option
						.setName("hex")
						.setDescription("Hex color code (e.g., #FF0000)")
						.setRequired(true),
				)
				.addStringOption((option) =>
					option
						.setName("name")
						.setDescription("Name of the role (optional)")
						.setRequired(false),
				)
				.setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
				.setDMPermission(false),
		);
	}

	async execute(
		client: DiscordClient<true>,
		interaction: DiscordChatInputCommandInteraction<"cached">,
	) {
		const targetUser = interaction.options.getUser("user", true);
		const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
		const hex = interaction.options.getString("hex", true);
		const customName = interaction.options.getString("name", false);

		if (!targetMember) {
			await interaction.reply({
				content: "Could not find that user in the server.",
				flags: MessageFlags.Ephemeral,
			});
			return;
		}

		// Validate hex code
		if (!HEX_REGEX.test(hex)) {
			await interaction.reply({
				content: "Invalid hex color code. Please use a valid format (e.g., #FF0000).",
				flags: MessageFlags.Ephemeral,
			});
			return;
		}

		const formattedHex = (hex.startsWith("#") ? hex : `#${hex}`).toUpperCase() as `#${string}`;

		await interaction.deferReply({ flags: MessageFlags.Ephemeral });

		const roleName = customName || `Color-${targetUser.id}`;
		
		const { CustomColorRole } = await import("@/mongo");
		const existingColorRole = await CustomColorRole.findOne({ guildId: interaction.guildId, userId: targetUser.id });
		
		// Find existing custom color role for this user safely
		let role = existingColorRole ? interaction.guild.roles.cache.get(existingColorRole.roleId) : null;
		if (!role) {
			role = interaction.guild.roles.cache.find(r => r.name === `Color-${targetUser.id}`);
		}

		try {
			const botHighestRole = interaction.guild.members.me?.roles.highest;
			
			const userColoredRoles = targetMember.roles.cache.filter(r => r.color !== 0 && (!role || r.id !== role.id));
			const highestUserColorRole = userColoredRoles.sort((a, b) => b.position - a.position).first();
			
			if (highestUserColorRole && botHighestRole && highestUserColorRole.position >= botHighestRole.position) {
				await interaction.followUp({
					content: `Cannot apply color because the user has a colored role (${highestUserColorRole.name}) that is higher than my highest role. Please move my role higher in the server settings.`,
					flags: MessageFlags.Ephemeral,
				});
				return;
			}

			// Always try to put custom colors as high as possible so they override milestone roles
			const targetPosition = botHighestRole ? Math.max(1, botHighestRole.position - 1) : 1;

			if (targetPosition <= 1) {
				console.warn(`Bot's highest role is too low to effectively manage custom colors. Please move the bot's role higher in the server settings.`);
			}

			if (role) {
				try {
					await role.edit({
						name: roleName,
						color: formattedHex,
					});
					const currentBotRole = interaction.guild.members.me?.roles.highest;
					const editTargetPosition = currentBotRole ? Math.max(1, currentBotRole.position - 1) : 1;
					await role.setPosition(editTargetPosition);
				} catch (e: unknown) {
					throw new Error(`Failed to edit existing role: ${e instanceof Error ? e.message : String(e)}`);
				}
			} else {
				try {
					role = await interaction.guild.roles.create({
						name: roleName,
						color: formattedHex,
						reason: `Custom color role set by ${interaction.user.tag}`,
					});
					// Recalculate target position because creating a role shifts all higher roles up by 1
					const currentBotRole = interaction.guild.members.me?.roles.highest;
					const createTargetPosition = currentBotRole ? Math.max(1, currentBotRole.position - 1) : 1;
					await role.setPosition(createTargetPosition);
				} catch (e: unknown) {
					throw new Error(`Failed to create role: ${e instanceof Error ? e.message : String(e)}`);
				}
			}

			// Remove other color roles from the user
			const { ColorRole } = await import("@/mongo");
			const guildColorRoles = await ColorRole.find({ guildId: interaction.guildId });
			const guildColorRoleIds = guildColorRoles.map(r => r.roleId);
			
			const colorRolesToRemove = targetMember.roles.cache.filter(r => 
				(r.name.startsWith("Color-") && r.id !== role?.id) || 
				guildColorRoleIds.includes(r.id)
			);
			if (colorRolesToRemove.size > 0) {
				await targetMember.roles.remove(colorRolesToRemove).catch(() => {});
			}

			if (!targetMember.roles.cache.has(role.id)) {
				await targetMember.roles.add(role).catch((e: unknown) => {
					throw new Error(`Failed to add role to user: ${e instanceof Error ? e.message : String(e)}`);
				});
			}

			// Save to DB
			await CustomColorRole.updateOne(
				{ guildId: interaction.guildId, userId: targetMember.id },
				{ $set: { roleId: role.id } },
				{ upsert: true }
			);

			await interaction.followUp({
				content: `Successfully set <@${targetUser.id}>'s nickname color to **${formattedHex}**!`,
				flags: MessageFlags.Ephemeral,
			});
		} catch (error: unknown) {
			console.error("Error setting custom color:", error);
			await interaction.followUp({
				content: `An error occurred while setting the color: ${error instanceof Error ? error.message : "Unknown error"}. Please make sure the bot has permission to manage roles and its role is higher than the target position.`,
				flags: MessageFlags.Ephemeral,
			});
		}
	}
}
