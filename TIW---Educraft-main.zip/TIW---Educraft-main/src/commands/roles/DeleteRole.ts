import type { DiscordClient } from "@/registry/DiscordClient";
import BaseCommand, {
	type DiscordChatInputCommandInteraction,
} from "@/registry/Structure/BaseCommand";
import { SlashCommandBuilder, MessageFlags, PermissionFlagsBits } from "discord.js";

export default class DeleteRoleCommand extends BaseCommand {
	constructor() {
		super(
			new SlashCommandBuilder()
				.setName("deleterole")
				.setDescription("Deletes a role from the entire server")
				.addRoleOption((option) =>
					option
						.setName("role")
						.setDescription("The role to delete")
						.setRequired(true),
				)
				.setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
				.setDMPermission(false),
		);
	}

	async execute(
		client: DiscordClient<true>,
		interaction: DiscordChatInputCommandInteraction<"cached">,
	) {
		const role = interaction.options.getRole("role", true);

		await interaction.deferReply({ flags: MessageFlags.Ephemeral });

		try {
			const botHighestRole = interaction.guild.members.me?.roles.highest;
			if (!botHighestRole || role.position >= botHighestRole.position) {
				await interaction.followUp({
					content: "I cannot delete a role that is higher than or equal to my highest role.",
					flags: MessageFlags.Ephemeral,
				});
				return;
			}

			const roleName = role.name;
			await role.delete(`Deleted by ${interaction.user.tag}`);

			await interaction.followUp({
				content: `Successfully deleted the role **${roleName}** from the server.`,
				flags: MessageFlags.Ephemeral,
			});
		} catch (error) {
			console.error("Error deleting role:", error);
			await interaction.followUp({
				content: "An error occurred while deleting the role. Please check my permissions.",
				flags: MessageFlags.Ephemeral,
			});
		}
	}
}
