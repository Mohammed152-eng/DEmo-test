import type { Guild, MessageCreateOptions, MessagePayload } from "discord.js";

export const logToChannel = (
	guild: Guild,
	channelId: string,
	options: string | MessagePayload | MessageCreateOptions,
) => {
	if (!channelId) return;
	
	const channel = guild.channels.cache.get(channelId);

	if (!channel?.isTextBased()) {
		console.error(`Bot Log channel ${channelId} not found or is not a text-based channel.`);
		return;
	}

	return channel.send(options);
};
