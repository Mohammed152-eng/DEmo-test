const createTask = (handler: () => void, interval: number) => {
	handler();
	setInterval(handler, interval);
};

export default createTask;
